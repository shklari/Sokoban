// q2.ts

export interface TreeNode {
  children: Tree[];
};

export interface TreeLeaf {
  value: number;
};

export type Tree = TreeNode | TreeLeaf;
export const isTreeNode = (x: any): x is TreeNode => x.children !== undefined;
export const isTreeLeaf = (x: any): x is TreeLeaf => x.value !== undefined;
export const isTree = (x: any): x is Tree => isTreeNode(x) || isTreeLeaf(x);
export const isEmptyTree = (x: Tree): boolean => isTreeNode(x) && x.children.length === 0;
// Example values:

export const t1: Tree = {value: 5};
export const t2: Tree = {children: [
                   {children: [{value: 1}, {value: 7}, {value: 5}]},
                   {value: 3},
                   {value: 10}]};
export const t3: Tree = {children: [
                   {children: [{value: 20}, {value: 5}, {value: 50}]},
                   {value: 5}]};

export const leftMostEven1 = (atree: Tree): number =>
  isEmptyTree(atree) || !isTree(atree)? -1 : 
  isTreeLeaf(atree)? ((atree.value % 2 === 0)? atree.value : -1) :
  !(leftMostEven1(atree.children[0]) === -1)? leftMostEven1(atree.children[0]) :
  leftMostEven1({children: atree.children.slice(1)});

  


export const leftMostEven2 = (atree: Tree): number =>
  leftMostEven$(atree,
                (x) => x,
                () => -1);


const leftMostEven$ = <T1, T2>(atree: Tree,
                               succ: ((x:number) => T1),
                               fail: (() => T2)): (T1 | T2) => {
    if(isEmptyTree(atree) || !isTree(atree)){
      return fail();
    }
    else{
      if(isTreeLeaf(atree)){
        if(atree.value % 2 === 0){
          return succ(atree.value);
        }
        else{return fail();}
      }
      else{
        return leftMostEven$(atree.children[0], succ, ()=> leftMostEven$({children: atree.children.slice(1)}, succ, fail));
      }
    }
}


console.log(leftMostEven2(t1));
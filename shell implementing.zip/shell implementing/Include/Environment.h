//
// Created by coral on 21/11/17.
//

#ifndef UNTITLED1_ENVIRONMENT_H
#define UNTITLED1_ENVIRONMENT_H

#include <string>
#include <iostream>
#include <vector>

#include "Files.h"
#include "Commands.h"

#include <string>
#include <vector>

using namespace std;

class Environment {
private:
    vector<BaseCommand*> commandsHistory;
    FileSystem fs;

public:
    Environment();
    void start();
    FileSystem& getFileSystem(); // Get a reference to the file system
    void addToHistory(BaseCommand *command); // Add a new command to the history
    const vector<BaseCommand*>& getHistory() const; // Return a reference to the history of commands

    //rule of 5
    virtual ~Environment();
    Environment(const Environment &other);
    Environment(Environment&& other);
    Environment& operator= (Environment &&other);
    Environment& operator= (const Environment &other);
    void copy(const vector<BaseCommand*> &other_history, const FileSystem &other_fs);
    void clear();

};
#endif //UNTITLED1_ENVIRONMENT_H

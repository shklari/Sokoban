//
// Created by coral on 21/11/17.
//

#ifndef UNTITLED1_COMMANDS_H
#define UNTITLED1_COMMANDS_H
#include <string>

#include "FileSystem.h"
using namespace std;


class BaseCommand {
private:
    string args;

public:
    BaseCommand(string args);
    string getArgs();
    virtual BaseCommand* instance()=0;
    virtual void execute(FileSystem & fs) = 0;
    virtual string toString() = 0;
    virtual ~BaseCommand();
};

class PwdCommand : public BaseCommand {
private:
public:
    virtual BaseCommand* instance();
    PwdCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
};

class CdCommand : public BaseCommand {
private:
public:
    CdCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    void ezer(Directory dir, vector<string> v, bool b, int i);
    BaseFile* path(vector<string>& v, FileSystem &fs);
    void check(vector<string>& v,string s);
    virtual BaseCommand* instance();
};

class LsCommand : public BaseCommand {
private:
public:
    void check(vector<string>& v,string s);
    BaseFile* path(vector<string>& v, FileSystem &fs);
    LsCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};

class MkdirCommand : public BaseCommand {
private:
public:
    MkdirCommand(string args);
    void execute(FileSystem & fs);
    string toString();
    void ezer(Directory *dir, vector<string> v, bool b, int i);
    virtual BaseCommand* instance();
};

class MkfileCommand : public BaseCommand {
private:
public:
    MkfileCommand(string args);
    void execute(FileSystem & fs);
    void ezer (Directory* dir,vector <string> &v , unsigned int i , string sub, int size);
    virtual string toString();
    virtual BaseCommand* instance();
};

class CpCommand : public BaseCommand {
private:
public:
    CpCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    void check(vector<string>& v,string s);
    BaseFile* path(vector<string>& v, FileSystem &fs);
    virtual BaseCommand* instance();
};

class MvCommand : public BaseCommand {
private:
public:
    MvCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    void check(vector<string>& v,string s);
    vector<BaseFile*>* path(vector<string>& v, FileSystem &fs);
    virtual BaseCommand* instance();
};

class RenameCommand : public BaseCommand {
private:
public:
    RenameCommand(string args);
    void check(vector<string>& v,string s);
    BaseFile* path(vector<string>& v, FileSystem &fs);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};

class RmCommand : public BaseCommand {
private:
public:
    RmCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};

class HistoryCommand : public BaseCommand {
private:
    const vector<BaseCommand *> & history;
public:
    HistoryCommand(string args, const vector<BaseCommand *> & history);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};


class VerboseCommand : public BaseCommand {
private:
public:
    VerboseCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};

class ErrorCommand : public BaseCommand {
private:
public:
    ErrorCommand(string args);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};

class ExecCommand : public BaseCommand {
private:
    const vector<BaseCommand *> & history;
public:
    ExecCommand(string args, const vector<BaseCommand *> & history);
    void execute(FileSystem & fs);
    virtual string toString();
    virtual BaseCommand* instance();
};
#endif //UNTITLED1_COMMANDS_H

//
// Created by coral on 21/11/17.
//

#ifndef UNTITLED1_GLOBALVARIABLES_H
#define UNTITLED1_GLOBALVARIABLES_H
extern unsigned int verbose;

// ... You may not change this file

#endif //UNTITLED1_GLOBALVARIABLES_H

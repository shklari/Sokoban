//
// Created by coral on 21/11/17.
//

#ifndef UNTITLED1_FILESYSTEM_H
#define UNTITLED1_FILESYSTEM_H
#include "Files.h"
//#include "Commands.h"
#include <iostream>
#include <cstdlib>

class FileSystem {
private:

    Directory* rootDirectory;
    Directory* workingDirectory;
    void copy(Directory* otherroot, Directory* otherwork);
public:

    FileSystem();
    Directory& getRootDirectory() const; // Return reference to the root directory
    Directory& getWorkingDirectory() const; // Return reference to the working directory
    void setWorkingDirectory(Directory *newWorkingDirectory); // Change the working directory of the file system
    void clear();
    //Rule of 5
    virtual ~FileSystem();



    FileSystem(FileSystem &&other);
    FileSystem(const FileSystem &other);

    FileSystem& operator=(FileSystem &&other);
    FileSystem& operator=(const FileSystem &other);

};
#endif //UNTITLED1_FILESYSTEM_H

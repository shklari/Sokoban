//
// Created by coral on 21/11/17.
//

/*
 * FileSystem.cpp
 *
 *  Created on: Nov 9, 2017
 *      Author: itay
 */

#include "../Include/FileSystem.h"
#include "../Include/Commands.h"
#include "../Include/GlobalVariables.h"
#include <iostream>
#include <algorithm>

using namespace std;

void FileSystem::clear(){
    delete rootDirectory;
    workingDirectory = nullptr;
    rootDirectory = nullptr;
}

void FileSystem::copy(Directory* otherroot, Directory* otherwork){
    rootDirectory = new Directory(*otherroot);
    string args = otherwork->getAbsolutePath();
    CdCommand cd(args);
    cd.execute(*this);
}


FileSystem::FileSystem():rootDirectory(new Directory("/", nullptr)), workingDirectory(rootDirectory){}


Directory& FileSystem::getRootDirectory() const{
    Directory* d = rootDirectory;
    return *d;
} // Return reference to the root directory

Directory& FileSystem::getWorkingDirectory() const{
    Directory* d = workingDirectory;
    return *d;
} // Return reference to the working directory

void FileSystem::setWorkingDirectory(Directory *newWorkingDirectory){workingDirectory = newWorkingDirectory;} // Change the working directory of the file system

//Rule of 5
FileSystem::~FileSystem(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "FileSystem::~FileSystem()";
    }
    clear();
}

FileSystem::FileSystem(const FileSystem &other):FileSystem(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "FileSystem::~FileSystem(const FileSystem &other)";
    }
    clear();
    copy(other.rootDirectory, other.workingDirectory);
}

FileSystem::FileSystem(FileSystem &&other):rootDirectory(other.rootDirectory),workingDirectory(other.workingDirectory){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "FileSystem::~FileSystem(FileSystem &&other)";
    }
    other.rootDirectory = nullptr;
    other.workingDirectory = nullptr;
}

FileSystem& FileSystem::operator= (const FileSystem &other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "FileSystem& FileSystem::operator= (const FileSystem &other)";
    }
    if(this != &other){
        clear();
        copy(other.rootDirectory, other.workingDirectory);
    }
    return *this;
}

FileSystem& FileSystem::operator= (FileSystem &&other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "FileSystem& FileSystem::operator= (FileSystem &&other)";
    }
    if(this != &other){
        clear();
        rootDirectory = other.rootDirectory;
        workingDirectory = other.workingDirectory;
        other.rootDirectory = nullptr;
        other.workingDirectory = nullptr;
    }
    return *this;
}



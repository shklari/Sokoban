//
// Created by coral on 21/11/17.
//

#include "../Include/Files.h"
#include "../Include/Commands.h"
#include "../Include/GlobalVariables.h"
#include "../Include/Environment.h"
#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;



Environment::Environment():commandsHistory(vector<BaseCommand*>()), fs(){}



Environment::~Environment(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    clear();
}

Environment::Environment(const Environment &other):commandsHistory(vector<BaseCommand*>()), fs(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    clear();
    copy(other.commandsHistory, other.fs);
}

Environment::Environment(Environment &&other):Environment(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    copy(other.commandsHistory, other.fs);
    other.commandsHistory.clear();
}

Environment& Environment::operator= (const Environment &other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    if(this != &other){
        clear();
        copy(other.commandsHistory, other.fs);
    }
    return *this;
}

Environment& Environment::operator= (Environment &&other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    if(this != &other){
        clear();
        commandsHistory = other.commandsHistory;
        fs = other.fs;
        other.commandsHistory.clear();
    }
    return *this;
}

void Environment::copy(const vector<BaseCommand*> &other_history, const FileSystem &other_fs){
    for(BaseCommand* b : other_history){
        commandsHistory.push_back(b->instance());
    }
    fs = other_fs;
}

void Environment::clear(){

    for(BaseCommand* b : commandsHistory){
        delete b;
        b = nullptr;
    }
    commandsHistory.clear();
}

void Environment ::start() {
    bool bre = true;
    while (bre) {

        string args;

        string str;
        string sc;
        bool b = false;
        BaseCommand *bc = nullptr;
        getline(cin, args);

        if (args.length() == 0)
            cout << "0";
        for (int i = 0; i < (int)args.length() && !b; i++) {
            try {
                if (args[i] == ' ') {
                    sc = args.substr(0, i);
                    str = args.substr(i + 1, args.length());
                    b = true;
                }
            }
            catch (out_of_range) {
                cout << endl;
                cout << "Invalid Input";
                sc = "";
                return;
            }


        }
        if (!b) {
            sc = args;
            str = "";
        }
        if (sc == "exit")
            return;
        if (sc == "pwd") {
            bc = new PwdCommand(str);
        }
        if (sc == "cd") {
            bc = new CdCommand(str);
        }
        if (sc == "ls") {
            bc = new LsCommand(str);
        }
        if (sc == "mkdir") {
            bc = new MkdirCommand(str);
        }
        if (sc == "mkfile") {
            bc = new MkfileCommand(str);
        }
        if (sc == "cp") {
            bc = new CpCommand(str);
        }
        if (sc == "mv") {
            bc = new MvCommand(str);
        }
        if (sc == "rename") {
            bc = new RenameCommand(str);
        }
        if (sc == "rm") {
            bc = new RmCommand(str);
        }
        if (sc == "history") {
            bc = new HistoryCommand(str, commandsHistory);
        }
        if (sc == "verbose") {
            bc = new VerboseCommand(str);

        }
        if (sc == "exec") {
            bc = new ExecCommand(str, commandsHistory);
        }
        if (!bc) {
            bc = new ErrorCommand(sc);
        }
        bc->execute(fs);
        addToHistory(bc);
        if (verbose == 2 || verbose == 3) {
            cout << endl;
            cout << bc->toString();
        }
        bc = nullptr;
        cout << endl;
    }
}

FileSystem& Environment::getFileSystem(){return fs;}

void Environment::addToHistory(BaseCommand *command){
    commandsHistory.push_back(command);
}

const vector<BaseCommand*>& Environment::getHistory() const{return commandsHistory;}


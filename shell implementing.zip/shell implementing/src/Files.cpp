//
// Created by coral on 21/11/17.
//
/*
 * Files.cpp
 *
 *  Created on: Nov 9, 2017
 *      Author: itay
 */
#include "../Include/Files.h"
#include <algorithm>
#include <iostream>
#include "../Include/GlobalVariables.h"

using namespace std;

//BasFile
BaseFile:: BaseFile(string name): name(name){ }
string BaseFile:: getName() const {return name;}
void BaseFile:: setName(string newName){name = newName;}
BaseFile::~BaseFile() {}


//File
File::File(string name, int size):BaseFile(name),size(size){}
int File::getSize(){return size;}
bool File::instance(){
    return true;
}






//Directory

void Directory::copy(const vector<BaseFile*> &other_children, Directory *other_parent){
    for(BaseFile *b : other_children){
        if(b->instance())
        {
            children.push_back(new File(b->getName(), b->getSize()));
        }
        else
        {
            Directory* dir1 = ((Directory*)b);
            Directory* dir = new Directory(*dir1);
            dir->parent = this;
            children.push_back((Directory*)dir);
        }
        parent = other_parent;

    }
}
void Directory::clear(){
    if(parent)
        parent = nullptr;
    for(BaseFile* b : children){
        delete b;
        b = nullptr;
    }
    children.clear();
}

Directory::Directory(string name, Directory *parent):BaseFile(name),children(vector<BaseFile*>()),parent(parent){}
Directory* Directory::getParent() const{return parent;}
void Directory::setParent(Directory *newParent){
    parent = newParent;
}

void Directory::addFile(BaseFile* file){

    children.push_back(file);
}

void Directory::removeFile(string name){ // Remove the file with the specified name from children
    for(int i = 0; i<(int)children.size(); i++)
    {
        if(children[i]->getName() == name)
        {
            delete children[i];
            children[i] = nullptr;
            children.erase(children.begin()+i);
            return;
        }
    }
}
void Directory::removeFile(BaseFile* file){ // Remove the file from children
    for(int i = 0; i<(int)children.size(); i++)
    {
        if(children[i] == file)
        {
            delete children[i];
            children[i] = nullptr;
            children.erase(children.begin()+i);
            return;
        }
    }
}

bool Directory::byName(BaseFile *b1, BaseFile *b2) {
    return b1->getName() < b2->getName();
}

bool Directory::bySize(BaseFile *b1, BaseFile *b2) {
    if ((int)b1->getSize() < (int)b2->getSize())
        return true;
    if ((int)b1->getSize() > (int)b2->getSize())
        return false;
    return  b1->getName() < b2->getName();
}

void Directory::sortByName(){ // Sort children by name alphabetically (not recursively)
    sort(children.begin(), children.end(), byName);
}
void Directory::sortBySize(){ // Sort children by size (not recursively)
    sort(children.begin(), children.end(), bySize);
}
vector<BaseFile*> Directory::getChildren(){ return children;}
int Directory::getSize(){ // Return the size of the directory (recursively)
    int size = 0;
    if(children.empty())
        return 0;
    for(int i=0; i<(int)children.size();i++){
        BaseFile* b = children[i];
        if(b->instance())
            size = size + ((File*)b)->getSize();
        else
            size = size + ((Directory*)b)->getSize();
    }
    return size;
}
string Directory::getAbsolutePath(){  //Return the path from the root to this
    if(parent==nullptr){
        return "/";
    }
    if(parent->parent) {
        return parent->getAbsolutePath() + "/" + getName();
    }
    else{
        return  "/" + getName();
    }
}

bool Directory::instance(){
    return false;
}

Directory* Directory::getRoot(){
    if(!parent){
        return this;
    }
    return parent->getRoot();
}

Directory::~Directory(){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory()";
    }
    clear();
}

Directory::Directory(const Directory &other):BaseFile(other.getName()),children(vector<BaseFile*>()),parent(other.parent){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(const Directory &other)";
    }
    clear();
    copy(other.children, other.parent);
}

Directory::Directory(Directory &&other):BaseFile(other.getName()), children(other.children),parent(other.parent){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory::~Directory(Directory &&other)";
    }
    Directory* d = other.parent;
    parent = d;
    other.getChildren().clear();
    other.parent = nullptr;
}

Directory& Directory::operator= (const Directory &other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory& Directory::operator= (const Directory &other)";
    }
    if(this != &other){
        clear();
        copy(other.children, other.parent);
    }
    return *this;
}

Directory& Directory::operator= (Directory &&other){
    if(verbose == 1 || verbose == 3){
        cout<< endl;
        cout << "Directory& Directory::operator= (Directory &&other)";
    }
    if(this != &other){
        clear();
        children = other.children;
        parent = other.parent;
        other.children.clear();
        other.parent = nullptr;
    }
    return *this;
}







//
// Created by coral on 21/11/17.
//

/*
 * Commands.cpp
 *
 *  Created on: Nov 9, 2017
 *      Author: itay
 */

#include "../Include/Files.h"
#include "../Include/Commands.h"
#include "../Include/GlobalVariables.h"
#include <iostream>
#include <cstdlib>

using namespace std;



//BaseFCommand


BaseCommand::BaseCommand(string args):args(args){}
string BaseCommand::getArgs(){return args;}
BaseCommand::~BaseCommand() {}

//PwdCommand

BaseCommand* PwdCommand::instance(){
    PwdCommand* b= new PwdCommand(getArgs());

    return b;
}

PwdCommand::PwdCommand(string args):BaseCommand(args){}

void PwdCommand::execute(FileSystem & fs){ // Every derived class should implement this function according to the document (pdf)
    cout << (fs.getWorkingDirectory()).getAbsolutePath();
}
string PwdCommand::toString(){
    string str = "PwdCommand" + getArgs();
    return str;
}
//CdCommand
BaseCommand* CdCommand::instance(){
    CdCommand* b= new CdCommand(getArgs());

    return b;
}
CdCommand::CdCommand(string args):BaseCommand(args){}

void CdCommand::check(vector<string>& v,string s){
    if(s.length() == 0)
    {
        v.clear();
        return;
    }
    string sub; unsigned int i;
    if(getArgs().at(0) =='/'){
        v.push_back("/");
        i=1;
    }
    else{
        i=0;
    }
    for(;i<getArgs().length();i++){
        if(getArgs().at(i) == '/'){
            if(i == getArgs().length()-1){
                v.clear();
                return;
            }
            if(sub.length()>0){
                v.push_back(sub);
                sub="";
            }
        }
        else{
            if(getArgs().at(i) ==' '){
                v.clear();
                return;
            }
            else{
                if(getArgs().at(i) =='.'){
                    if(sub.length() > 0 || i == getArgs().length()-1 || getArgs().at(i+1) != '.'){
                        v.clear();
                        return;
                    }
                    else{
                        v.push_back("..");
                        sub = "";
                        i++;
                    }
                }
                else
                    sub += getArgs().at(i);
            }
        }
    }
    if(sub.length() > 0)
        v.push_back(sub);
}

BaseFile* CdCommand::path(vector<string>& v, FileSystem &fs){
    unsigned int i;
    BaseFile* base;
    Directory* dir= nullptr;
    if(v.size() == 0){
        return nullptr;
    }
    if(v.at(0) == "/"){
        dir = &fs.getRootDirectory();
        i = 1;
    }
    else{
        dir = &fs.getWorkingDirectory();
        i = 0;
    }
    for(; i < v.size(); i++)
    {
        bool b = false;
        if(v.at(i) == ".."){
            if(!dir->getParent()){
                return nullptr;
            }
            dir = dir->getParent();
            b = true;
        }

        for(unsigned int j = 0; j < dir->getChildren().size() && !b; j++)
        {
            if(dir->getChildren()[j]->getName() == v[i])
            {
                b = true;
                base = dir->getChildren()[j];
                if(i < v.size() - 1 && !base->instance())
                {
                    dir = (Directory*)base;
                }
                else{
                    if(i == v.size()-1){
                        return (File*)base;
                    }
                    else{
                        return nullptr;
                    }
                }
            }
        }
        if(!b) {
            return nullptr;
        }
    }
    return dir;
}

void CdCommand::execute(FileSystem & fs){
    vector<string> v = vector<string>();
    check(v, getArgs());
    if(v.empty()){
        cout << endl;
        cout << "The system cannot find the file specified";
    }
    else{
        BaseFile* b = path(v, fs);
        if(!b || b->instance()){
            cout<< endl;
            cout << "The system cannot find the file specified";
        }
        else{
            fs.setWorkingDirectory((Directory*)b);
        }
    }
}
string CdCommand::toString(){
    return "Cd "+ getArgs();

}

//LsCommand
BaseCommand* LsCommand::instance(){
    LsCommand* b= new LsCommand(getArgs());

    return b;
}


LsCommand::LsCommand(string args):BaseCommand(args){}

void LsCommand::check(vector<string>& v,string s){
    if(s.length() == 0)
    {
        v.clear();
        return;
    }
    string sub; unsigned int i;
    if(getArgs().at(0) =='/'){
        v.push_back("/");
        i=1;
    }
    else{
        i=0;
    }
    for(;i<getArgs().length();i++){
        if(getArgs().at(i) == '/'){
            if(sub.length()>0){
                v.push_back(sub);
                sub="";
            }
            else{
                v.clear();
                return;
            }
        }
        else{
            if(getArgs().at(i) ==' '){
                v.clear();
                return;
            }
            else{
                if(getArgs().at(i) =='.'){
                    if(sub.length() > 0 || i == getArgs().length()-1 || getArgs().at(i+1) != '.'){
                        v.clear();
                        return;
                    }
                    else{
                        v.push_back("..");
                        sub = "";
                        i++;
                    }
                }
                else
                    sub += getArgs().at(i);
            }
        }
    }
    if(sub.length() > 0)
        v.push_back(sub);
}

BaseFile* LsCommand::path(vector<string>& v, FileSystem &fs){
    unsigned int i;
    BaseFile* base;
    Directory* dir= nullptr;
    if(v.size() == 0){
        return nullptr;
    }
    if(v.at(0) == "/"){
        dir = &fs.getRootDirectory();
        i = 1;
    }
    else{
        dir = &fs.getWorkingDirectory();
        i = 0;
    }
    for(; i < v.size(); i++)
    {
        bool b = false;
        if(v.at(i) == ".."){
            if(!dir->getParent()){
                return nullptr;
            }
            dir = dir->getParent();
            b = true;
        }

        for(unsigned int j = 0; j < dir->getChildren().size() && !b; j++)
        {
            if(dir->getChildren()[j]->getName() == v[i])
            {
                b = true;
                base = dir->getChildren()[j];
                if(i < v.size() - 1 && !base->instance())
                {
                    dir = (Directory*)base;
                }
                else{
                    if(i == v.size()-1){
                        return base;
                    }
                    else{
                        return nullptr;
                    }
                }
            }
        }
        if(!b) {
            return nullptr;
        }
    }
    return dir;
}

void LsCommand::execute(FileSystem & fs){
    string sub = getArgs();
    Directory* d = &fs.getWorkingDirectory();
    bool b = false;
    bool empty = false;
    if(getArgs().length() == 0)
    {
        empty = true;
    }
    if(!empty && getArgs().at(0) == '-'){
        if(getArgs().length() < 2 || getArgs().at(1) != 's'){
            cout << endl;
            cout << "The system cannot find the file specified";
            return;
        }
        b = true;
        if(getArgs().length() == 2) {
            d = &fs.getWorkingDirectory();
            sub = "";
        }
        else {
            sub = getArgs().substr(3, sub.length());
        }
    }

    vector<string> v = vector<string>();
    if(sub.length() > 0) {
        check(v, sub);
        if(v.empty()){
            cout << endl;
            cout << "The system cannot find the file specified";
            return;
        }
        BaseFile* bas = path(v,fs);
        if(!bas || bas->instance()) {
            cout << endl;
            cout << "The system cannot find the file specified";
            return;
        }
        bas = path(v,fs);
        if(!bas || bas->instance()){
            cout << endl;
            cout << "The system cannot find the file specified";
            return;
        } else d = (Directory*)bas;
    }


    int size = d->getChildren().size();
    if(!b)
        d->sortByName();
    else
        d->sortBySize();
    for (int i=0; i<size; i++)
    {
        cout << endl;
        BaseFile* son = d->getChildren()[i];
        if(son->instance()) {
            cout << "File";
            cout << "\t" << son->getName() << "\t" << son->getSize();
        }
        else {
            cout << "Dir" << "\t";
            cout << "\t" << son->getName() << "\t" << son->getSize();
        }

    }


}

string LsCommand::toString(){return "Ls " + getArgs();}

//MkdirCommand
BaseCommand* MkdirCommand::instance(){
    MkdirCommand* b= new MkdirCommand(getArgs());

    return b;
}

MkdirCommand::MkdirCommand(string args):BaseCommand(args){}
void MkdirCommand::execute(FileSystem & fs){

    vector<string> v = vector<string>();
    Directory *dir; string sub="", sub1=getArgs(); int i, j = 0;
    if(getArgs().at(0) == ' '){
        cout << endl;
        cout << "Invalid args";
        return;
    }
    if(sub1[0] == '/')
    {
        dir = &fs.getRootDirectory(); i = 1;
    }
    else
    {
        dir = &fs.getWorkingDirectory(); i = 0;
    }
    for(; i< (int)sub1.length(); i++)
    {
        if(sub1[i] == ' ')
        {
            cout << endl;
            cout << "Invalid args";
            return;
        }
        if(sub1[i] == '/')
        {
            if(sub.length() > 0){
                v.push_back(sub);
                sub = "";
                j++;
            }
            else{
                cout << endl;
                cout << "Invalid args";
                return;
            }
        }
        else
            sub += sub1[i];
    }
    if(sub.length() > 0)
    {
        v.push_back(sub);
        sub = "";
        j++;
    }
    ezer(dir, v, false, 0);
}


string MkdirCommand::toString(){
    return "Mkdir " + getArgs();
}
void MkdirCommand::ezer(Directory *dir, vector<string> v, bool b, int i){
    if(i == (int)v.size()) {
        if (!b) {
            cout << endl;
            cout << "The directory is already exist";
        }
    } else{
        bool found = false;
        for( int j = 0; j <(int)dir->getChildren().size() && !found;j ++)
        {
            BaseFile* b = dir->getChildren()[j];
            if(v[i] == b->getName()){
                if(b->instance() || i == (int)v.size()-1){
                    cout << endl;
                    cout << "The directory is already exist";
                    return;
                }
                found = true;
                ezer((Directory*)b, v, b, i+1);
            }
        }
        if(!found)
        {
            b = true;
            Directory* d = new Directory(v.at(i), dir);
            dir->addFile(d);
            ezer(d, v, b, i+1);
            d = nullptr;
        }
    }
}


//MkfileCommand
BaseCommand* MkfileCommand::instance(){
    MkdirCommand* b= new MkdirCommand(getArgs());

    return b;
}
MkfileCommand::MkfileCommand(string args):BaseCommand(args){}
void MkfileCommand::ezer (Directory* dir,vector <string>& v , unsigned int i , string sub, int size){
    if(i == v.size()-1){
        bool b = false;
        for(int j = 0; j < (int)dir->getChildren().size() && !b;j ++)
        {
            if(v[i] == dir->getChildren()[j]->getName()){
                b = true;
                cout << endl;
                cout << "File already exist";
                return;
            }
        }
        if(!b){
            //File* f = new File(sub,size);
            dir->addFile(new File(sub,size));
        }
    }
    else{
        bool found = false;
        for(int j = 0; j < (int)dir->getChildren().size() && !found;j ++)
        {
            if(v[i] == dir->getChildren()[j]->getName() && !dir->getChildren()[j]->instance()){
                found = true;
                ezer((Directory*)dir->getChildren()[j], v, i+1, sub,size);
            }
        }
        if(!found){
            cout << endl;
            cout << "the system cannot find the path specified";
            return;
        }
    }
}
void MkfileCommand::execute(FileSystem & fs) {
    vector<string> v = vector<string>();
    Directory *dir;
    string sub = "", sub1 = getArgs();
    int i, size = 0, j = 0;
    bool stop = false;
    if (sub1[0] == '/') {
        dir = &fs.getRootDirectory();
        i = 1;
    } else {
        dir = &fs.getWorkingDirectory();
        i = 0;
    }
    for (; i < (int)sub1.length() && !stop; i++) {
        if (sub1[i] == '/') {
            if (sub.length() > 0) {
                v.push_back(sub);
                sub = "";
                j++;
            } else {
                cout << endl;
                cout << "the system cannot find the path specified";
                return;;
            }
        } else {
            if (sub1[i] == ' ') {
                if (i == (int)sub1.length() - 1) {
                    cout << endl;
                    cout << "the system cannot find the path specified";
                    return;
                } else {
                    if (sub.length() > 0) {
                        v.push_back(sub);
                        j++;
                        size = atoi(sub1.substr(i + 1, sub1.length()).c_str());
                    } else {
                        cout << endl;
                        cout << "the system cannot find the path specified";
                        return;
                    }
                }
                stop = true;
            } else {
                sub += sub1[i];
            }
        }
    }
    if(!stop){
        cout << endl;
        cout << "the system cannot find the path specified";
        return;
    }

    if(size > 0 && !v.empty())
        ezer(dir,v,0,sub,size);
    else{
        cout << endl;
        cout << "the system cannot find the path specified";
    }
}
string MkfileCommand::toString(){
    return "Mkfile " + getArgs();
}

//CpCommand
BaseCommand* CpCommand::instance(){
    CpCommand* b= new CpCommand(getArgs());

    return b;
}

CpCommand::CpCommand(string args):BaseCommand(args){}

void CpCommand::check(vector<string>& v,string s){
    if(s.length() == 0)
    {
        v.clear();
        return;
    }
    string sub; int i; bool stop = false;
    if(s[0]=='/'){
        v.push_back("/");
        i=1;
    }
    else{
        i=0;
    }
    for(;i<(int)s.length() && !stop;i++){
        if(s[i]=='/'){
            if(sub.length()>0){
                v.push_back(sub);
                sub="";
            }
        }
        else{
            if(s[i]==' '){
                v.clear();
                return;
            }
            else{
                if(s[i]=='.'){
                    if(((int)sub.length() > 0 || i==(int)s.length()-1) || s[i+1]!='.'){
                        v.clear();
                        return;
                    } else{
                        v.push_back("..");
                        i++;
                    }
                }
                else{
                    sub += s[i];
                }
            }
        }
    }
    if((int)sub.length() > 0)
        v.push_back(sub);
}

BaseFile* CpCommand::path(vector<string>& v, FileSystem &fs){
    int i;
    BaseFile* base;
    Directory* dir;
    if(v.empty())
        return nullptr;
    if(v[0] == "/"){
        dir = &fs.getRootDirectory();
        i = 1;
    }
    else{
        dir = &fs.getWorkingDirectory();
        i = 0;
    }
    for(; i < (int)v.size(); i++)
    {
        bool b = false;
        if(v[i] == ".."){
            if(dir->getParent()){
                dir = dir->getParent();
            }
            else{
                return nullptr;
            }
        }
         else{
        for(int j = 0; j < (int)dir->getChildren().size() && !b; j++)
        {
            if(dir->getChildren()[j]->getName() == v[i])
            {
                b = true;
                base = dir->getChildren()[j];
                if(i < (int)v.size() - 1 && !base->instance())
                {
                    dir = (Directory*)base;
                }
                else{
                    if(i == (int)v.size()-1){
                        return base;
                    }
                    else{
                        return nullptr;
                    }
                }
            }
        }
        if(!b)
        {
            return nullptr;
        }}
    }
    return dir;
}

void CpCommand::execute(FileSystem & fs){
    BaseFile* b2;
    BaseFile* b1;
    vector<string> v1= vector<string>();
    vector<string> v2 = vector<string>();
    bool b = false;
    string sub = getArgs();
    for(int i =0; i< (int)sub.length() && !b; i++){
        if(sub[i] ==' '){
            if(i == 0 || i == (int)sub.length()-1){
                cout << endl;
                cout << "No Such file or directory";
                return;
            }
            else{
                CpCommand::check(v1, sub.substr(0, i));
                CpCommand::check(v2, sub.substr(i+1, sub.length()));
            }
            b = true;
        }
    }


    if(!b | v1.empty() | v2.empty()){
        cout << endl;
        cout << "No Such file or directory";
        return;
    }
    else{
        b1 = CpCommand::path(v1, fs);
        b2 = CpCommand::path(v2, fs);
        if((b1 == 0 || b2 == 0) || b2->instance()){
            cout << endl;
            cout << "No Such file or directory";
            return;
        }
        else {
            if(!b1->instance()){
                Directory* dir = (Directory*)b1;
                Directory* dir1 = &fs.getWorkingDirectory();
                Directory* dir2 = &fs.getRootDirectory();
                if(dir==dir1||dir==dir2||dir==dir1->getParent()){
                    cout << endl;
                    cout << "can't move BaseFile";
                    return;
                }
                else{
                    Directory* dir3 = (Directory*)b2;
                    for(int i = 0; i<(int)dir3->getChildren().size(); i ++){
                        if(dir3->getChildren()[i]->getName() == b1->getName()){
                            cout << endl;
                            cout << "Directory is already exits";
                            return;
                        }
                    }
                    Directory* dir4 = new Directory(*dir);
                    dir3->addFile(dir4);
                    return;
                }
            }
            else{
                Directory* dir1 = (Directory*)b2;
                for(int i = 0; i<(int)dir1->getChildren().size(); i ++){
                    if(dir1->getChildren()[i]->getName() == b1->getName()){
                        cout << endl;
                        cout << "Directory is already exits";
                        return;
                    }
                }
                File* dir = new File(b1->getName(), b1->getSize());
                dir1->addFile(dir);
                return;
            }
        }

    }
}

string CpCommand::toString(){
    return "Cp " + getArgs();
}


//MvCommand

MvCommand::MvCommand(string args):BaseCommand(args){}
BaseCommand* MvCommand::instance(){
    MvCommand* b= new MvCommand(getArgs());

    return b;
}
string MvCommand::toString(){
    return "Mv " + getArgs();
}

void MvCommand::execute(FileSystem & fs){
    Directory* dir = &fs.getWorkingDirectory();
    Directory* dir2;
    CdCommand cd1("");
    CdCommand cd2("");
    CpCommand cp("");
    bool b = false;
    bool b1=false;
    Directory* curr;
    Directory* curr1= nullptr;
    Directory* curr3;
    Directory* dmove;
    string str1;
    string str2;
    string strmove;
    string sub = getArgs();
    for(unsigned int i=0; i<sub.length()&&!b1;i++){
        if(sub[i]==' '){
            if(i==0||i==sub.length()-1){
                cout << endl;
                cout << "No such file or directory";
                return;
            }
            str1 = sub.substr(0,i);
            str2 = sub.substr(i+1,sub.length());
            b1= true;
        }
    }
    if(!b1){
        cout << endl;
        cout << "No such file or directory";
        return;
    }
    cd2 = CdCommand(str2);
    if(str1.length() == 0){
        cout << endl;
        cout << "Can’t move directory";
        fs.setWorkingDirectory(dir);
        return;
    }
    for(int j = str1.length()-1; j>=0 && !b; j--){
        if(str1[j]=='/'){
            if(j==0) {
                curr1 = &fs.getRootDirectory();
                if (str1.length() == 1) {
                    strmove = "";
                } else
                    strmove = str1.substr(1, str1.length());
                b = true;
            }
            else{if(j == (int)str1.length()-1){
                    cout << endl;
                    cout << "No such file or directory";
                    return;
                }
                strmove =str1.substr(j+1,str1.length());
                str1 = str1.substr(0,j);
                cd1 = CdCommand(str1);
                b = true;
            }
        }
    }
    if(!b){
        curr1 = &fs.getWorkingDirectory();
        strmove = str1;
    }
    cp = CpCommand(sub);

    curr = &fs.getRootDirectory();
    if(fs.getWorkingDirectory().getParent()!=0){
        curr3= fs.getWorkingDirectory().getParent();
    }
    else {
        curr3= curr;
    }
    if(curr1) {
        unsigned int s = curr1->getChildren().size();
        bool que = false;
        BaseFile *bas = nullptr;
        for (unsigned int k = 0; k < s && !que; k++) {
            bas = curr1->getChildren()[k];
            if (bas->getName() == strmove) {
                if (!bas->instance()) {
                    if ((Directory *) bas == dir || (Directory *) bas == dir->getParent()) {
                        cout << endl;
                        cout << "Can’t move directory";
                        fs.setWorkingDirectory(dir);
                        return;
                    }
                }
                cd2.execute(fs);
                dir2 = &fs.getWorkingDirectory();
                if (dir2 == curr1) {
                    cout << endl;
                    cout << "Can’t move directory";
                    fs.setWorkingDirectory(dir);
                    return;
                }
                fs.setWorkingDirectory(dir);
                cp.execute(fs);
                curr1->removeFile(strmove);
                fs.setWorkingDirectory(dir);
                return;

            }

        }
        cout << endl;
        cout << "No such file or directory";
        fs.setWorkingDirectory(dir);
        return;
    }


    cd1.execute(fs);
    dmove = &fs.getWorkingDirectory();
    unsigned int s = dmove->getChildren().size();
    bool que = false;
    BaseFile *bas = nullptr;
    for (unsigned int k = 0; k < s && !que; k++) {
        bas = dmove->getChildren()[k];
        if (bas->getName() == strmove) {
            if (!bas->instance()) {
                if ((Directory *) bas == curr3 || (Directory *) bas == curr || (Directory *) bas == dir) {
                    cout << endl;
                    cout << "Can’t move directory";
                    fs.setWorkingDirectory(dir);
                    return;
                }
            }
            fs.setWorkingDirectory(dir);
            cd2.execute(fs);
            dir2 = &fs.getWorkingDirectory();
            if (dir2 == dmove) {
                cout << endl;
                cout << "Can’t move directory";
                fs.setWorkingDirectory(dir);
                return;
            }
            fs.setWorkingDirectory(dir);
            cp.execute(fs);
            dmove->removeFile(strmove);
            fs.setWorkingDirectory(dir);
            return;
        }
    }
    cout << endl;
    cout << "No such file or directory";
    fs.setWorkingDirectory(dir);
    return;

}






//RenameCommand

RenameCommand::RenameCommand(string args):BaseCommand(args){}
BaseCommand* RenameCommand::instance(){
    RenameCommand* b= new RenameCommand(getArgs());

    return b;
}
string RenameCommand::toString(){
    return "Rename " + getArgs();
}


void RenameCommand::check(vector<string>& v,string s){
    if(s.length() == 0)
    {
        v.clear();
        return;
    }
    string sub; unsigned int i; bool stop = false;
    if(s[0]=='/'){
        v.push_back("/");
        i=1;
    }
    else{
        i=0;
    }
    for(;i<s.length() && !stop;i++){
        if(s[i]=='/'){
            if(sub.length()>0){
                v.push_back(sub);
                sub="";
            }
        }
        else{
            if(s[i]==' '){
                v.clear();
                return;
            }
            else{
                if(s[i]=='.'){
                    if((sub.length() > 0 || i==s.length()-1) || s[i+1]!='.'){
                        v.clear();
                        return;
                    } else{
                        v.push_back("..");
                        i++;
                    }
                }
                else{
                    sub += s[i];
                }
            }
        }
    }
    if(sub.length() > 0)
        v.push_back(sub);
}

BaseFile* RenameCommand::path(vector<string>& v, FileSystem &fs){
    unsigned int i;
    BaseFile* base;
    Directory* dir;
    if(v.empty())
        return nullptr;
    if(v[0] == "/"){
        dir = &fs.getRootDirectory();
        i = 1;
    }
    else{
        dir = &fs.getWorkingDirectory();
        i = 0;
    }
    for(; i < v.size(); i++)
    {
        bool b = false;
        if(v[i] == ".."){
            if(dir->getParent()){
                dir = dir->getParent();
            }
            else{
                return nullptr;
            }
        }
        else{
            for(unsigned int j = 0; j < dir->getChildren().size() && !b; j++)
            {
                if(dir->getChildren()[j]->getName() == v[i])
                {
                    b = true;
                    base = dir->getChildren()[j];
                    if(i < v.size() - 1 && !base->instance())
                    {
                        dir = (Directory*)base;
                    }
                    else{
                        if(i == v.size()-1){
                            return base;
                        }
                        else{
                            return nullptr;
                        }
                    }
                }
            }
            if(!b)
            {
                return nullptr;
            }}
    }
    return dir;
}


void RenameCommand::execute(FileSystem & fs){
    string str1;
    string newName;
    string sub;
    sub = getArgs();
    bool b1 = false;
    vector<string>v = vector<string>();
    CdCommand cd1("");
    BaseFile* bas = nullptr;
    Directory* pa = nullptr;
    for(int i=0; i<(int)sub.length()&&!b1;i++){
        if(sub[i]==' '){
            if(i==0||i==(int)sub.length()-1){
                cout << endl;
                cout << "No such file or directory";
                return;
            }
            newName = sub.substr(i+1,sub.length());
            str1 = sub.substr(0,i);
            b1= false;
            string oldName = "";
            for(int i =str1.length()-1; i>=0 && !b1; i--){
                if(str1[i] == '/'){
                    if(i == (int)str1.length()-1){
                        if(i == 0){
                            cout << endl;
                            cout << "cant rename the root directory";
                            return;
                        }
                        cout << endl;
                        cout << "No such file or directory";
                        return;
                    }
                    if(i == 0){
                        pa = &fs.getRootDirectory();
                        oldName = str1.substr(1, str1.length());
                    }
                    else{
                        oldName = str1.substr(i+1, str1.length());
                        str1 = str1.substr(0, i-1);
                    }
                    b1 = true;
                }
            }
            if(b1 && str1.length() == 0){
                cout << endl;
                cout << "cant rename the root directory";
                return;
            }
            if(!b1){
                pa = &fs.getWorkingDirectory();
                oldName = str1;
            }
            b1 = false;
            if(!pa) {
                check(v, str1);
                if (v.empty()) {
                    cout << endl;
                    cout << "No such file or directory";
                    return;
                }
                bas = path(v, fs);
                if (!bas && bas->instance()) {
                    cout << endl;
                    cout << "No such file or directory";
                    return;
                }
                pa = (Directory *) bas;
            }
            bas = 0;
            for(unsigned int i = 0; i < pa->getChildren().size(); i++){
                if(pa->getChildren()[i]->getName() == oldName){
                    bas = pa->getChildren()[i];
                }
                if(pa->getChildren()[i]->getName() == newName){
                    b1 = true;
                }
            }
            if(b1){
                return;
            }
            if(!bas){
                cout << endl;
                cout << "No such file or directory";
                return;
            }
            if(!bas->instance()) {
                if ((Directory *) bas == &fs.getWorkingDirectory()) {
                    cout << endl;
                    cout << "Cant rename the working directory";
                    return;
                }
                if ((Directory *) bas == &fs.getRootDirectory()) {
                    cout << endl;
                    cout << "cant rename the root directory";
                    return;
                }
            }
            bas->setName(newName);
            return;
        }
    }
    if(!b1){
        cout << endl;
        cout << "No such file or directory";
        return;
    }
}

//RmCommands
RmCommand::RmCommand(string args):BaseCommand(args){}
BaseCommand* RmCommand::instance(){
    RmCommand* b= new RmCommand(getArgs());

    return b;
}
string RmCommand::toString(){
    return "Rm " + getArgs();
}

void RmCommand::execute(FileSystem & fs){
    Directory* w1=&fs.getWorkingDirectory();
    Directory* w2;
    Directory* w3;
    BaseFile* bf;
    CdCommand com1("");
    CdCommand com2("");
    bool b1 = false, b2 = false;
    string sub = getArgs();
    for(int i = sub.length()-1; i>=0&&!b1; i--) {
        if (sub[i] == '/') {
            b1 = true;
            if (i == (int)sub.length() - 1) {
                if(i == 0){
                    cout << endl;
                    cout << "cant remove directory";
                    return;
                }
                cout << endl;
                cout << "No such file or directory";
                return;
            }
            if (i == 0) {
                w2 = &fs.getRootDirectory();
                for (unsigned int j = 0; j < w2->getChildren().size() && !b2; j++) {
                    if (w2->getChildren()[j]->getName() == sub.substr(1, sub.length())) {
                        bf = w2->getChildren()[j];
                        if (bf->instance()) {
                            fs.setWorkingDirectory(w1);
                            w2->removeFile(bf);
                            return;
                        } else {
                            w3 = (Directory *) bf;
                            if(w3 == w2 || w3 == w1){
                                cout << endl;
                                cout << "cant remove directory";
                                return;
                            }
                            fs.setWorkingDirectory(w3);
                            while (w3->getChildren().size() != 0) {
                                RmCommand r = RmCommand(w3->getChildren()[0]->getName());
                                r.execute(fs);
                                fs.setWorkingDirectory(w3);
                            }
                            fs.setWorkingDirectory(w1);
                            w2->removeFile(bf);
                            return;
                        }
                        b2 = true;
                    }
                }
            } else {
                com1 = CdCommand(sub.substr(0, i));
                com1.execute(fs);
                w2 = &fs.getWorkingDirectory();
                if (w1 == w2) {
                    fs.setWorkingDirectory(w1);
                    cout << endl;
                    cout << "cant remove directory";
                    fs.setWorkingDirectory(w1);
                    return;
                } else {

                    for (unsigned int j = 0; j < w2->getChildren().size() && !b2; j++) {
                        if (w2->getChildren()[j]->getName() == sub.substr(i + 1, sub.length())) {
                            bf = w2->getChildren()[j];
                            if (bf->instance()) {
                                fs.setWorkingDirectory(w1);
                                w2->removeFile(bf);
                                return;
                            } else {
                                w3 = (Directory *) bf;
                                if(w3 == &fs.getRootDirectory() || w3 == w1->getParent())
                                fs.setWorkingDirectory(w3);
                                while (w3->getChildren().size() != 0) {
                                    RmCommand r = RmCommand(w3->getChildren()[0]->getName());
                                    r.execute(fs);
                                    fs.setWorkingDirectory(w3);
                                }
                                fs.setWorkingDirectory(w1);
                                w2->removeFile(bf);
                                return;
                            }
                            b2 = true;
                        }
                    }
                    cout << endl;
                    cout << "no such file or directory";
                    fs.setWorkingDirectory(w1);
                    return;
                }
            }
        }
    }
    b2 = false;
    if(!b1){
        w2=w1;
        for(unsigned int j=0; j<w2->getChildren().size() && !b2;j++){
            if(w2->getChildren()[j]->getName() == sub){
                bf = w2->getChildren()[j];
                if(bf->instance()){
                    fs.setWorkingDirectory(w1);
                    w2->removeFile(bf);
                    return;
                }
                else{
                    w3=(Directory*)bf;
                    fs.setWorkingDirectory(w3);
                    while(w3->getChildren().size() != 0){
                        RmCommand r = RmCommand(w3->getChildren()[0]->getName());
                        r.execute(fs);
                        fs.setWorkingDirectory(w3);
                    }
                    fs.setWorkingDirectory(w1);
                    w2->removeFile(bf);
                    return;
                }
                b2 = true;
            }
        }
        if(!b2){
            cout << endl;
            cout << "no such file or directory";
            fs.setWorkingDirectory(w1);
            return;
        }

    }
}


HistoryCommand::HistoryCommand(string args, const vector<BaseCommand *> & history):BaseCommand(args), history(history){}
BaseCommand* HistoryCommand::instance(){
    HistoryCommand* b= new HistoryCommand(getArgs(),history);

    return b;
}

void HistoryCommand::execute(FileSystem & fs){
    if(history.empty()) return;
    for(unsigned int i = 0; i < history.size(); i++)
    {
        cout << endl;
        cout << i << "	" << history[i]->toString();
    }
}


string HistoryCommand::toString(){
    return "History " + getArgs();
}



VerboseCommand::VerboseCommand(string args): BaseCommand(args){}
BaseCommand* VerboseCommand::instance(){
    VerboseCommand* b= new VerboseCommand(getArgs());

    return b;
}

void VerboseCommand::execute(FileSystem & fs){
    string sub = getArgs();
    int v = 0;
    try{
        v = atoi(sub.c_str());
    }
    catch(exception e){
        cout << endl;
        cout << "Wrong Verbose input";
        return;
    }
    if(v> 3 || v < 0){
        cout << endl;
        cout << "Wrong Verbose input";
        return;
    }
    verbose = v;
}

string VerboseCommand::toString(){
    return "Verbose " + getArgs();
}


ErrorCommand::ErrorCommand(string args):BaseCommand(args){}
BaseCommand* ErrorCommand::instance(){
    ErrorCommand* b= new ErrorCommand(getArgs());

    return b;
}

void ErrorCommand::execute(FileSystem & fs){
    cout<<endl;
    cout<<getArgs()<<": unknown command";
}
string ErrorCommand::toString(){
    return "Error "+ getArgs();
}


ExecCommand::ExecCommand(string args, const vector<BaseCommand *> & history):BaseCommand(args), history(history){}
BaseCommand* ExecCommand::instance(){
    ExecCommand* b= new ExecCommand(getArgs(),history);

    return b;
}

void ExecCommand::execute(FileSystem & fs){
    unsigned int num;
    try{
        num = atoi(getArgs().c_str());
    }
    catch(exception e){
        cout << endl;
        cout << "Wrong input";
        return;
    }

    if(num>history.size()-1 || num<0){
        cout<<endl;
        cout<<"command not found";
        return;
    }
    if(num < history.size())
        history[num]->execute(fs);
    else {
        cout << endl;
        cout << "Command not found";
    }

}

string ExecCommand::toString(){
    return "Exec " + getArgs();
}





package Ticks;
import java.util.*;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import Gui.*;
import Tools.*;

public abstract class Tower implements Visitor {
	int move;
	public int click;
	public Board b;
	protected int range;
	public Grass c;
	public ImageIcon im, cim;
	public LinkedList<Road> targets;
	public int x, y;

	public Tower(Grass c, Board b, int x, int y, ImageIcon im) {
		this.x = x;
		this.y = y;
		this.c = c;
		move = 0;// counts the number of the Creep's timer's rounds
		click = 2;// how many timer rounds doe's it take for the Creep to move
		range = 1;
		this.b = b;
		targets = new LinkedList<Tools.Road>();
		tar();
		this.im = im;
		this.c.t = this;
		b.Towers.add(this);
	}

	protected void tar() {
		int newx = 0, newy = b.y;
		for (Road tar : b.path) {
			if (Math.abs(newx - x) <= range & Math.abs(newy - y) <= range)
				targets.add(tar);
			else
				targets.remove(tar);
			newx = newx + tar.x;
			newy = newy - tar.y;
		}
		
	}

	public void tickHappend() {
		if (move % click == 0) {
			Iterator<Road> itar = targets.iterator();
			boolean s = true;
			while (itar.hasNext() & s) {
				LinkedList<Creep> toshoot = itar.next().creep;
				if (!toshoot.isEmpty()) {
					s = false;
					toshoot.getFirst().impact(this);
				}
			}
			move = 0;
		}
		move++;
	}

	abstract public void visit(Creep cr);

}

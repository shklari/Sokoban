package Ticks;
import java.awt.Image;

import javax.swing.ImageIcon;

import Gui.Board;

public class Naji extends Creep {
	public int pois;

	public Naji(Board b, int x, int y) {
		super(b, x, y);
		pois = 0;
		click = 1;
		k = 5;
		im = new ImageIcon("src/pics/naji-1.png");
		iz = im;
		it = new ImageIcon("src/pics/naji-2.png");
		this.im.setImage(im.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
		this.it.setImage(it.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
	}

	@Override
	public void impact(Visitor v) {
		v.visit(this);
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
		if (pois > 0)
			pois--;
	}

}

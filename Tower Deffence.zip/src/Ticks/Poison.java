package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Poison extends Tower {

	public Poison(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/poison.gif"));
		cim = new ImageIcon("src/pics/Poison.png");

		// c.setImage(new ImageIcon("src/pics/3.png"));
	}

	@Override
	public void visit(Guli a) {
		a.HP = a.HP - 20;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		a.pois = 10;
		a.r.setImage(cim);
	}

	@Override
	public void visit(Mike a) {

	}

	@Override
	public void visit(Naji a) {
		a.pois = 10;
		a.r.setImage(cim);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
	}

}

package Ticks;
import java.awt.Image;

import javax.swing.ImageIcon;
import Gui.*;

public class Knight extends Creep {
	public int pois;

	public Knight(Board b, int x, int y) {
		super(b, x, y);
		pois = 0;
		im = new ImageIcon("src/pics/abir-1.png");
		iz = im;
		it = new ImageIcon("src/pics/abir-2.png");
		k = 7;
		this.im.setImage(im.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
		this.it.setImage(it.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
	}

	@Override
	public void impact(Visitor v) {
		v.visit(this);
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
		if (pois > 0)
			pois--;
	}

}

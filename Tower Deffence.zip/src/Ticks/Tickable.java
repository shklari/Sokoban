package Ticks;

public interface Tickable {
	public void tickHappend();
}

package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Magic extends Tower {
	
	public Magic(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/magic.gif"));
		cim = new ImageIcon("src/pics/Magic.png");
		// c.setImage(new ImageIcon("src/pics/4.png"));
	}

	@Override
	public void visit(Guli a) {
		a.HP = a.HP - 25;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		if (a.pois == 0)
			a.HP = a.HP - 30;
		else {
			a.HP = a.HP - 60;
			a.pois--;
		}
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Mike a) {
		a.HP = a.HP - 10;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Naji a) {
		if (a.pois == 0)
			a.HP = a.HP - 10;
		else {
			a.HP = a.HP - 15;
			a.pois--;
		}
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();

	}

}

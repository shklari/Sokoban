package Ticks;
import java.awt.Point;
import java.util.Stack;

import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Dino extends Tower {
	
	public int angle;
	int x1;int x2;
	int speed=2;
	public Dino(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/dino-right.gif"));
		cim = new ImageIcon("src/pics/dino.png");
		
		x1=x;
		x2=y;
		
		
		
		
		// c.setImage(new ImageIcon("src/pics/3.png"));
	}
	public void path()
	{
		angle+= 1;
		  x = x1+(int) (3 * Math.sin(angle));
		  y = x2+(int) (3 * Math.cos(angle));
	}
	@Override
	public void visit(Guli a) {
		a.HP = a.HP - 15;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		a.HP = a.HP - 8;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Mike a) {
		a.HP = a.HP - 10;
		a.r.setImage(cim);
		a.die(this);
		

	}

	@Override
	public void visit(Naji a) {
		a.HP = a.HP - 11;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
		path();
		tar();	
	}
	
}

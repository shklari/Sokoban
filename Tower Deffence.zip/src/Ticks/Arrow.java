package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Arrow extends Tower {

	public Arrow(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/arrow.gif"));
		range = 2;
		tar();
		this.cim = new ImageIcon("src/pics/Arrow.png");
		click = 1;
		// c.setImage(im);
	}

	@Override
	public void visit(Guli a) {
		a.HP = a.HP - 15;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(Mike a) {
		a.HP = a.HP - 30;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Naji a) {
		if (a.pois == 0) {
			a.HP = a.HP - 30;
			a.r.setImage(cim);
		} else {
			a.HP = a.HP - 45;
			a.pois--;
			a.r.setImage(cim);

		}
		a.die(this);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
	}

}

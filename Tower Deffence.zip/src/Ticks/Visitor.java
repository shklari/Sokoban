package Ticks;

public interface Visitor extends Tickable {
	public void visit(Guli a);

	public void visit(Knight a);

	public void visit(Mike a);

	public void visit(Naji a);
}

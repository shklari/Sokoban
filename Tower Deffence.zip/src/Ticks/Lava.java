package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Lava extends Kaschan {

	public Lava(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/lava.gif"));
		cim = new ImageIcon("src/pics/Lava.png");
		// c.setImage(new ImageIcon("src/pics/1.gif"));
	}

	@Override
	public void visit(Guli a) {
		a.r.setImage(cim);
		a.HP = a.HP - 15;
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		if (a.pois == 0)
			a.HP = a.HP - 10;
		else {
			a.HP = a.HP - 20;
			a.pois--;
		}
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Mike a) {
		a.HP = a.HP - 15;
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Naji a) {
		if (a.pois == 0)
			a.HP = a.HP - 15;
		else {
			a.HP = a.HP - (int) (15 * 1.5);
			a.pois--;
		}
		a.r.setImage(cim);
		a.die(this);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}
}

package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Goko extends Tower {
	int H = 1;
	int hit = 0;

	public Goko(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/goko.gif"));
		cim = new ImageIcon("src/pics/Goko.png");

		// c.setImage(new ImageIcon("src/pics/3.png"));
	}

	public void checkHit() {
		if (hit % 10 == 0) {
			H = H * 2;
		}
	}

	@Override
	public void visit(Guli a) {
		a.HP = a.HP - a.k * H;
		a.r.setImage(cim);
		hit++;
		checkHit();
		a.die(this);
	}

	@Override
	public void visit(Knight a) {
		a.HP = a.HP - a.k * H;
		a.r.setImage(cim);
		hit++;
		checkHit();
		a.die(this);
	}

	@Override
	public void visit(Mike a) {
		a.HP = a.HP - a.k * H;
		a.r.setImage(cim);
		hit++;
		checkHit();
		a.die(this);

	}

	@Override
	public void visit(Naji a) {
		a.HP = a.HP - a.k * H;
		a.r.setImage(cim);
		hit++;
		checkHit();
		a.die(this);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
	}
}

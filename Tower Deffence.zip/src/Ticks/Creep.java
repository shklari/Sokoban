package Ticks;
import javax.swing.ImageIcon;

import Gui.*;
import Tools.*;
public abstract class Creep implements Tickable {
	public int HP;
	public Road r;
	public int click, move;
	public Board b;
	public ImageIcon im;
	public int x;
	public int y;
	public int k;
	public ImageIcon iz;
	public ImageIcon it;
	public int despose=0;

	// x y paint
	public Creep(Board b, int x, int y) {
		move = 0;// counts the number of the Creep's timer's rounds
		click = 2;// how many timer rounds doe's it take for the Creep to move
		HP = 100;
		this.b = b;
		this.x = x;
		this.y = y;
		r = (Road) b.path.getFirst();
		r.creep.add(this);
		b.Creeps.add(this);
	}

	public void change() {
		if (im == iz) {
			im = it;
		} else {
			im = iz;
		}
	}

	public void tickHappend() {
		change();
		int a=click;
		if(despose>0)
		{
			a=click*2;
			despose--;
			
		}
		if (move % a == 0&move!=0) {

			r.creep.remove(this);
			r.setImage();
			if (move / click < b.path.size()) {
				x += r.x;
				y -= r.y;
				r = b.path.get(b.path.indexOf(r)+1);
				r.creep.add(this);
				
				r.setImage();
			}
			
		}
		move++;
		
	}

	protected void die(Tower a) {
		if (HP <= 0) {
			b.Creeps.remove(this);
			r.creep.remove(this);
			r.setImage();
			b.dead++;
			b.toupdate.add(r);
		}
	}

	abstract public void impact(Visitor v);
}

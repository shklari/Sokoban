package Ticks;
import java.awt.Image;

import javax.swing.ImageIcon;

import Gui.Board;

public class Mike extends Creep {

	public Mike(Board b, int x, int y) {
		super(b, x, y);
		im = new ImageIcon("src/pics/mike-1.png");
		iz = im;
		it = new ImageIcon("src/pics/mike-2.png");
		k = 5;
		this.im.setImage(im.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
		this.it.setImage(it.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
	}

	@Override
	public void impact(Visitor v) {
		v.visit(this);
	}

}

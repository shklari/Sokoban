package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;
import Tools.Road;

public class Kaschan extends Tower {

	public Kaschan(Grass c, Board b, int x, int y, ImageIcon image) {
		super(c, b, x, y, image);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tickHappend() {
		for (Road road : targets) {
			if (!road.creep.isEmpty())
				for (Creep cr : road.creep) {
					cr.impact(this);
				}
		}
	}

	@Override
	public void visit(Guli a) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void visit(Knight a) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void visit(Mike a) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void visit(Naji a) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

}

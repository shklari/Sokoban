package Ticks;
import javax.swing.ImageIcon;

import Gui.Board;
import Tools.Grass;

public class Sam extends Tower implements Visitor {

	public Sam(Grass c, Board b, int x, int y) {
		super(c, b, x, y, new ImageIcon("src/pics/sam.gif"));
		cim = new ImageIcon("src/pics/sam.png");

		// c.setImage(new ImageIcon("src/pics/3.png"));
	}


	@Override
	public void visit(Guli a) {
		a.despose = 6;
		a.r.setImage(cim);
	}

	@Override
	public void visit(Knight a) {
		a.despose = 12;
		a.r.setImage(cim);
	}

	@Override
	public void visit(Mike a) {
		a.despose = 6;
		a.r.setImage(cim);
		a.HP-=10;
		a.die(this);
	}

	@Override
	public void visit(Naji a) {
		a.despose = 6;
		a.r.setImage(cim);
	}

	@Override
	public void visit(Creep cr) {
		throw new RuntimeException("bad casting");
	}

	@Override
	public void tickHappend() {
		super.tickHappend();
	}

}

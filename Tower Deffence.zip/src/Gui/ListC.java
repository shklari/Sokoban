package Gui;
import java.util.Comparator;

public class ListC implements Comparator<String> {

	@Override
	public int compare(String n1, String n2) {
		// TODO Auto-generated method stub
		if(Double.parseDouble(n1.split(" ")[3])<Double.parseDouble(n2.split(" ")[3]))
			return 1;
		else
			return -1;
	}

}

package Gui;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class Tabs extends JPanel implements ActionListener {
	public Integer s0 = 3, s1 = 3, s2 = 3, s3 = 3, s4 = 1, s5 = 1,s6=1;
	Board b;
	public JLabel[] but;
	JButton[] x;
	JPanel[] q;

	public Tabs(Board b) {
		super();
		this.b = b;
		this.setLayout(new GridLayout(7,1));
		blabla();

	}

	public void blabla() {
		but = new JLabel[7];
		x = new JButton[7];
		q = new JPanel[7];
		but[0] = (new JLabel("Arrow: " + s0));
		but[0].setFocusable(false);
		JButton a1 = new JButton(new ImageIcon("src/pics/arrow.gif"));
		a1.addActionListener(this);
		x[0] = a1;
		JPanel p = new JPanel();
		p.add(a1);
		p.add(but[0]);
		q[0] = p;
		but[1] = (new JLabel("Lava: " + s1));
		but[1].setFocusable(false);
		JButton a2 = new JButton(new ImageIcon("src/pics/lava.gif"));
		a2.addActionListener(this);
		x[1] = a2;
		JPanel p1 = new JPanel();
		p1.add(a2);
		p1.add(but[1]);
		q[1] = p1;
		but[2] = (new JLabel("Magic: " + s2));
		but[2].setFocusable(false);
		JButton a3 = new JButton(new ImageIcon("src/pics/magic.gif"));
		a3.addActionListener(this);
		x[2] = a3;
		JPanel p2 = new JPanel();
		p2.add(a3);
		p2.add(but[2]);
		q[2] = p2;
		but[3] = (new JLabel("Poison: " + s3));
		but[3].setFocusable(false);
		JButton a4 = new JButton(new ImageIcon("src/pics/poison.gif"));
		a4.addActionListener(this);
		x[3] = a4;
		JPanel p3 = new JPanel();
		p3.add(a4);
		p3.add(but[3]);
		q[3] = p3;
		but[4] = (new JLabel("Goko: " + s4));
		but[4].setFocusable(false);
		JButton a5 = new JButton(new ImageIcon("src/pics/Goko.gif"));
		a5.addActionListener(this);
		x[4] = a5;
		JPanel p4 = new JPanel();
		p4.add(a5);
		p4.add(but[4]);
		q[4] = p4;
		but[5] = (new JLabel("Sam: " + s5));
		but[5].setFocusable(false);
		JButton a6 = new JButton(new ImageIcon("src/pics/Sam.gif"));
		a6.addActionListener(this);
		x[5] = a6;
		JPanel p5 = new JPanel();
		p5.add(a6);
		p5.add(but[5]);
		q[5] = p5;
		but[6] = (new JLabel("Dino: " + s6));
		but[6].setFocusable(false);
		JButton a7 = new JButton(new ImageIcon("src/pics/dino-left.gif"));
		a7.addActionListener(this);
		x[6] = a7;
		JPanel p6= new JPanel();
		p6.add(a7);
		p6.add(but[6]);
		q[6] = p6;
		for(int i=0;i<q.length;i++)
		{
			x[i].setOpaque(false);
			x[i].setFocusable(false);
			q[i].setOpaque(false);
			this.add(q[i]);
		}
		this.setOpaque(false);
		
	}

	public boolean isEmpty() {
		return s0 == 0 & s1 == 0 & s2 == 0 & s3 == 0&s4==0&s5==0&s6==0;
	}

	public void refill() {
		s0 = 3;
		s1 = 3;
		s2 = 3;
		s3 = 3;
		s4 = 1;
		s5 = 1;
		s6=1;
		but[0].setText("Arrow: " + s0);
		but[1].setText("Lava: " + s1);
		but[2].setText("Magic: " + s2);
		but[3].setText("Poison :" + s3);
		but[4].setText("Goko: " + s4);
		but[5].setText("Sam: " + s5);
		but[6].setText("Dino: " + s6);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		boolean go = true;
		for (int i = 0; i < 7 & go; i++)
			if (src == x[i]) {
				go = false;
				switch (i) {
				case 0:
					if (s0 > 0)
						b.next = new String("Arrow");
					break;
				case 1:
					if (s1 > 0)
						b.next = new String("Lava");
					break;
				case 2:
					if (s2 > 0)
						b.next = new String("Magic");
					break;
				case 3:
					if (s3 > 0)
						b.next = new String("Poison");
					break;
				case 4:
					if (s4 > 0)
						b.next = new String("Goko");
					break;
				case 5:
					if(s5>0)
						b.next=new String("Sam");
					break;
				case 6:
					if (s6 > 0)
						b.next = new String("Dino");
					break;
				}
			}
	}

}

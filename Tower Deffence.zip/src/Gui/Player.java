package Gui;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Player {
	String name;
	double score;
	
	public Player(String name, double score)
	{
		this.name=name;
		this.score=score;
	}
	public String toString()
	{
		return "name: "+name+" score: "+score;
	}
	public void writePlayer()
	{
		try {
		    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("src/players.txt", true)));
		    out.println(toString());
		    out.close();
		} catch (IOException e) {
		    //exception handling left as an exercise for the reader
		}
	}
}

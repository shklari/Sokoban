package Gui;


import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;
import javax.swing.Timer;

import Ticks.Arrow;
import Ticks.Creep;
import Ticks.Dino;
import Ticks.Goko;
import Ticks.Guli;
import Ticks.Knight;
import Ticks.Lava;
import Ticks.Magic;
import Ticks.Mike;
import Ticks.Naji;
import Ticks.Poison;
import Ticks.Sam;
import Ticks.Tower;
import Tools.Cell;
import Tools.Grass;
import Tools.Road;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Board extends JPanel implements ActionListener, MouseListener {
	public Main g;
	public Cell[][] c;
	public LinkedList<Road> path;
	public LinkedList<Creep> Creeps;
	public LinkedList<Tower> Towers;
	public LinkedList<Road> toupdate;// Roads to change
	public Timer T;
	public int y;// remember the position of the starting point
	public int wave = 0;// the number of the wave
	public int HP = 20;
	public int[] togo;// the array of the creeps to go in each wave
	public int dead;// for the creeps who were killed on duty
	public double time = 0;// the number of seconds the game is running
	public ImageIcon image;
	public String next = null;// indicates for the next Tower is going to be
	public int start;

	public Board(Cell[][] luah, Main g) {
		this.g = g;
		T = new Timer(500, this);
		c = new Cell[32][32];
		for (int i = 0; i < 32; i++)
			for (int j = 0; j < 32; j++) {
				if (luah[i][j].x == 0 & luah[i][j].y == 0)
					c[i][j] = new Grass(0, 0);
				else
				{
					c[i][j] = new Road(luah[i][j].x, luah[i][j].y);
				}
			}
		Road startPoint = null;
		y = -1;
		for (int i = 0; i < 32; i++) {
			boolean stop = false;
			if (c[i][0].x != 0 || c[i][0].y != 0) {// checking if there's no
													// other Cell around which
													// leads to the current Cell
				stop = !(c[i][1].x == -1 & c[i][1].y == 0);
				if (!stop & i > 0)
					stop = !(c[i - 1][0].x == 0 & c[i - 1][0].y == -1);
				if (!stop & i < 31)
					stop = !(c[i + 1][0].x == 0 & c[i + 1][0].y == 1);
				if (stop) {
					if (startPoint != null)
						throw new RuntimeException("more than one starting point");
					else {
						startPoint = (Road) c[i][0];
						y = i;
					}
				}
			}
		}
		if (startPoint == null)
			throw new RuntimeException("no starting point");
		else {
			path = new LinkedList<Road>();
			buildPath(startPoint, 0, y);
		}
		Creeps = new LinkedList<Creep>();
		Towers = new LinkedList<Tower>();
		toupdate = new LinkedList<Road>();
		dead = 0;
		addMouseListener(this);
		setVisible(true);
		g.but = new Tabs(this);
		g.pack();
		start(wave);
	}

	private void buildPath(Road cell, int x, int y) {
		if (x == 31 & cell.x == 1)
			path.add(cell);
		else {
			int newx = c[y][x].x + x, newy = (-1) * c[y][x].y + y;
			if (c[newy][newx].y == 0 & c[newy][newx].x == 0)
				throw new RuntimeException("Illegal path: " + y + " " + x);
			path.add(cell);
			buildPath((Road) c[newy][newx], newx, newy);
		}
	}

	protected void start(int gal) {
		g.but.refill();
		togo = new int[4];
		for (int i = 0; i < 4; i++)
			togo[i] = (int) Math.pow(2, gal);// the number of Creeps in each
		repaint();									// kind
	}

	private boolean checkToGo() {// checks if there are more Creeps to go and
									// send them if there are
		if (time % 1 > 0 | Math.random() < 0.5)
			return true;
		boolean what = false;
		for (int i = 0; i < togo.length & !what; i++)
			if (togo[i] != 0)
				what = true;
		if (what) {
			int rnd = (int) (Math.random() * togo.length);
			what = togo[rnd] == 0;
			while (what) {
				rnd = (rnd + 1) % togo.length;
				what = togo[rnd] == 0;
			}
			togo[rnd]--;
			switch (rnd) {
			case 0:
				Guli gul = new Guli(this, 0, y);
				break;
			case 1:
				Mike mik = new Mike(this, 0, y);
				break;
			case 2:
				Knight kni = new Knight(this, 0, y);
				break;
			case 3:
				Naji naj = new Naji(this, 0, y);
				break;
			}
			return true;
		}
		return false;
	}

	private void notifyEveryone() {
		for (Road road : toupdate) {
			road.setImage();
		}
		toupdate = new LinkedList<Road>();
		if (!checkToGo() && Creeps.isEmpty()) {// checks if there are more
												// Creeps to go and send them if
												// there are. in addition,
												// checks if there are more
												// Creeps alive
			wave++;// the wave is over
			start(wave);
			T.stop();
			repaint();
		} else {
			repaint();
			LinkedList<Creep> toremove = new LinkedList<Creep>();
			for (Creep creep : Creeps) {
				if (creep.move / creep.click == path.size()) {
					HP--;
					toremove.add(creep);
					creep.r.creep.remove(this);
					creep.r.setImage();
				} else
					creep.tickHappend();
			}
			for (Creep creep : toremove) {
				Creeps.remove(creep);
			}
			for (Tower tower : Towers) {
				tower.tickHappend();
			}
			
			time = time + 0.5;
			if (HP <= 0 | wave > 4)
			{
				T.stop();
			}
			
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		repaint();
		if (e.getSource() == T) {
			notifyEveryone();
			g.showof();
		}
		
	}

	public void paint(Graphics gr) {
		super.paint(gr);
		
				for (int i = 0; i < 32; i++)
					for (int j = 0; j < 32; j++) {
						Cell cell = c[i][j];
						if (cell.x == 0 & cell.y == 0)
							gr.drawImage(((Grass) c[i][j]).image.getImage(), j * 25, i * 25, this);
						else
							gr.drawImage(((Road) c[i][j]).image.getImage(), j * 25, i * 25, this);

					}
				for (Creep creep : Creeps) {
					if (creep.x > -1 & creep.x < 32 & creep.y > -1 & creep.y < 32) {
						creep.im.paintIcon(this, gr, creep.x * 25, creep.y * 25);
					}
				}
				for (Tower tower : Towers) {
					tower.im.paintIcon(this, gr, tower.x * 25, tower.y * 25);
				}
				if(HP==0)
				{
					ImageIcon lost=new ImageIcon("src/pics/lose.png");
					lost.paintIcon(this, gr, this.getX(), this.getY());
				}
				repaint();
			
		
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (image != null) {
			this.image.setImage(image.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
			image.paintIcon(this, g, 800, 800);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x = (int) e.getX() * 32 / 800, y = e.getY() * 32 / 800;
		Cell cell = c[y][x];
		Grass grass = null;
		if (!T.isRunning() & !g.but.isEmpty() & next != null & cell instanceof Grass
				&& (grass = (Grass) cell).t == null) {// putting a Tower on the
														// Board
			Tower t = null;
			switch (next.charAt(0)) {
			case 'A':
				t = new Arrow(grass, this, x, y);
				grass.t = t;
				g.but.s0--;
				g.but.but[0].setText("Arrow: " + g.but.s0);
				g.but.but[0].setFocusable(false);
				break;
			case 'L':
				t = new Lava(grass, this, x, y);
				grass.t = t;
				g.but.s1--;
				g.but.but[1].setText("Lava: " + g.but.s1);
				break;
			case 'M':
				t = new Magic(grass, this, x, y);
				grass.t = t;
				g.but.s2--;
				g.but.but[2].setText("Magic: " + g.but.s2);
				break;
			case 'P':
				t = new Poison(grass, this, x, y);
				grass.t = t;
				g.but.s3--;
				g.but.but[3].setText("Poison: " + g.but.s3);
				break;
			case 'G':
				t = new Goko(grass, this, x, y);
				grass.t = t;
				g.but.s4--;
				g.but.but[4].setText("Goko: " + g.but.s4);
				break;
			case 'S':
				t=new Sam(grass, this, x, y);
				grass.t = t;
				g.but.s5--;
				g.but.but[5].setText("Sam: " + g.but.s5);
				break;
			case 'D':
				t = new Dino(grass, this, x, y);
				grass.t = t;
				g.but.s6--;
				g.but.but[6].setText("Dino: " + g.but.s6);
				break;
			}
			if (t != null)
				Towers.add(t);
			// grass.setImage();
		}
		if (cell instanceof Grass && (grass = (Grass) cell).t != null) {
			for (Road road : grass.t.targets) {
				road.setImage(new ImageIcon("target.png"));
				toupdate.add(road);
			}
			repaint();
		}
		next = null;
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

}

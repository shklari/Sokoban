package Gui;
import java.awt.BorderLayout;
import Ticks.*;
import Tools.Cell;
import Tools.LevelLoader;

import javax.swing.Timer;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.beancontext.BeanContextEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.TextUI;

public class Main extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Board b;
	public int numberOfStage;
	public JButton[] buttons;
	public LevelLoader l;
	public JLabel content;
	public JLabel sec = new JLabel("time: " + 0);
	public JLabel HP = new JLabel("HP: " + 20);
	public JLabel wave = new JLabel("wave: " + 0);
	public Tabs but;
	public JButton menu;
	public JButton re;
	int i = 0;
	public String[][] winners; 
	public Button getwin;

	public Main() throws IOException {
		super("Tower Deffense - Main Window");
		winners=new String[5][2];
		content = new JLabel(new ImageIcon("src/pics/g.gif"));
		this.l = new LevelLoader();
		try {
			l.load("src/levels.txt");
		} catch (IOException e) {
			System.out.println("Could not load file!!");
		}

		content.setSize(new Dimension(1200, 900));
		this.setContentPane(content);
		numberOfStage = l.getLevelsCount();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(1200, 900));

		start();
		this.pack();
		this.getContentPane().setVisible(true);
		this.setVisible(true);
	}

	public void start() {
		this.getContentPane().setVisible(false);
		this.getContentPane().removeAll();
		getwin=new Button("winners");
		getwin.addActionListener(this);
		getwin.setPreferredSize(new Dimension(200,100));
		getwin.setFont(new Font("Serif", Font.PLAIN, 30));
		content.setIcon(new ImageIcon("src/pics/g.jpg"));
		this.getContentPane().setPreferredSize(new Dimension(1200, 900));
		this.getContentPane().setLayout(new GridBagLayout());
		this.getContentPane().add(getwin);
		buttons = new JButton[numberOfStage];
		for (int i = 0; i < buttons.length; i++) {
			// make new button name
			JButton btn = new JButton("Stage:  " + i);
			buttons[i] = btn;
			btn.setFont(new Font("Serif", Font.PLAIN, 30));
			btn.addActionListener(this);
			btn.setPreferredSize(new Dimension(200, 100));
			btn.setBackground(Color.white);
			// add button to panel
			this.getContentPane().add(btn);
		}
		this.getContentPane().setPreferredSize(new Dimension(1200, 900));
		this.getContentPane().setVisible(true);
		this.pack();

	}

	// @Override
	public void actionPerformed(ActionEvent evt) {
		Object src = evt.getSource();
		for (int i = 0; i < numberOfStage; i++)
			if (src == buttons[i]) {
				game(l.get(i));
				this.i = i;
			}
		if (evt.getSource() == menu) {
			start();
		}
		else if (evt.getSource() == re) {
			game(l.get(i));
		}
		else if(evt.getSource()==getwin)
		{
			winners();
			JPanel h=new JPanel(new GridLayout(5,2));
			for(int i=0;i<5&&winners[i][0]!=null;i++)
			{
				JLabel z=new JLabel();
				z.setText(winners[i][0].toString());
				z.setFont(new Font("Serif", Font.PLAIN, 54));
				JLabel w=new JLabel(winners[i][1].toString());
				w.setFont(new Font("Serif", Font.PLAIN, 54));
				z.setPreferredSize(new Dimension(100,100));
				w.setPreferredSize(new Dimension(100,100));
				h.add(z);
				h.add(w);
			}
			JFrame win = new JFrame("Winners");
			win.setFont(new Font("Serif", Font.PLAIN, 50));
			win.setPreferredSize(new Dimension(50,30));;
			Dimension d=new Dimension();
			d.height=100;
			d.width=100;
			d.setSize(500, 500);
			win.setPreferredSize(d);
			win.add(h);
			win.setSize(1000, 1000);
			win.setVisible(true);
		}
	}

	public void game(Cell[][] luah) {
		this.getContentPane().setVisible(false);
		this.getContentPane().removeAll();
		this.getContentPane().setPreferredSize(new Dimension(1200, 800));
		this.getContentPane().setLayout(null);
		
		content.setIcon(new ImageIcon("src/pics/g.jpg"));

		menu = new JButton("Menu");
		menu.addActionListener(this);
		re = new JButton("Restart");
		re.addActionListener(this);
		JButton fast = new JButton(new AbstractAction("Fast mode") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if ((b.T.isRunning())) {
					b.T.stop();
					switch (b.T.getDelay()) {
					case 500:
						b.T.setDelay(250);
						break;
					case 250:
						b.T.setDelay(500);
						break;
					}
					b.T.start();
				}
			}
		});
		JButton start = new JButton(new AbstractAction("Start") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!b.T.isRunning() & b.HP > 0 & b.wave < 5)
					b.T.start();
			}
		});
		sec.setFont(new Font("Serif", Font.PLAIN, 30));
		HP.setFont(new Font("Serif", Font.PLAIN, 30));
		wave.setFont(new Font("Serif", Font.PLAIN, 30));
		JPanel panel=new JPanel();
		panel.add(sec);
		panel.add(HP);
		panel.add(wave);
		JPanel t=new JPanel(new GridLayout(3,1));
		menu.setFocusable(false);
		re.setFocusable(false);
		fast.setFocusable(false);
		menu.setBackground(Color.white);
		re.setBackground(Color.white);
		fast.setBackground(Color.white);
		start.setBackground(Color.white);
	/*	menu.setPreferredSize(new Dimension(40, 30));
		re.setPreferredSize(new Dimension(40, 30));
		fast.setPreferredSize(new Dimension(40, 30));
		start.setPreferredSize(new Dimension(40, 30));*/
		menu.setOpaque(false);
		re.setOpaque(false);
		fast.setOpaque(false);
		start.setOpaque(false);
		JPanel panel1=new JPanel();
		panel1.add(menu);
		panel1.add(re);
		panel1.add(fast);
		panel1.add(start);
		start.setFocusable(false);
		start.setVisible(true);
		b = new Board(luah, this);
		b.setPreferredSize(new Dimension(800, 800));
		b.setFocusable(false);
		this.getContentPane().setFocusable(false);
	/*	for (JPanel z : but.q) {
			z.setFocusable(false);
			z.setOpaque(false);
			this.getContentPane().add(z);
			pack();
		}*/
		t.add(but);
		t.add(panel1);
		t.add(panel);
		panel.setFocusable(false);
		panel.setOpaque(false);
		this.getContentPane().add(t);
		t.setBounds(20, 0, 150, 800);
		panel1.setOpaque(false);
		t.setOpaque(false);
		this.getContentPane().add(b);
		b.setBounds(300, 0, 800, 800);
		b.setVisible(true);
		this.pack();
		this.getContentPane().setFocusable(false);
		this.setFocusable(false);

		this.getContentPane().setVisible(true);
	}

	public void showof() {
		
		if (b.HP <= 0 | b.wave > 4) {
			sec.setText("time: " + b.time);
			HP.setText("HP: " + b.HP);
			wave.setText("Creeps passed: " + (20 - b.HP) + "		" + "Creeps destroyed: " + b.dead);
			if(b.wave>4)
			{
				JLabel win1=new JLabel(new ImageIcon("src/pics/win.png"));
				
				JFrame win=new JFrame("winner");
				win.setVisible(false);
				win.setLayout(null);
				win.setContentPane(win1);
				win.setSize(new Dimension(800, 800));
				JLabel ask=new JLabel("would you like save your win?");
				ask.setBounds(200, 100, 500, 30);
				ask.setFont(new Font("Serif", Font.PLAIN, 40));
				ask.setPreferredSize(new Dimension(500,30));
				win.getContentPane().add(ask);
				JTextField name=new JTextField();
				name.setBounds(200, 300, 150, 30);
				name.setFont(new Font("Serif", Font.BOLD, 40));
				name.setPreferredSize(new Dimension(70,30));
				win.getContentPane().add(name);
				JButton save= new JButton(new AbstractAction("save") {
					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;

					@Override
					public void actionPerformed(ActionEvent e) {
						if(name.getText()!="")
						{
							Player p=new Player(name.getText(),20*b.HP/b.time);
							p.writePlayer();
						}
					}
				});
				save.setBounds(200, 500, 150, 30);
				save.setPreferredSize(new Dimension(70,30));
				win1.setFocusable(false);
				win.getContentPane().add(save);
				win.setVisible(true);
				
			}
			else
			{
				JLabel lose1=new JLabel(new ImageIcon("src/pics/lose.jpg"));
				JFrame lose=new JFrame("loser");
				lose.setVisible(true);
				lose.setContentPane(lose1);
				lose1.setPreferredSize(new Dimension(800, 800));
				lose.setSize(new Dimension(800, 800));	
				lose.setVisible(true);
			}
			
		} else {
			sec.setText("time: " + b.time);
			HP.setText("HP: " + b.HP);
			wave.setText("wave: " + (new Integer(b.wave + 1)).toString());
		}
	}
	
	public void winners()
	{
		try {
			java.util.List<String> a=Files.readAllLines(Paths.get("src/players.txt"));
			a.sort(new ListC());
			int j=0;
			while(j<5)
			{
				winners[j][0]=a.get(j).split(" ")[1];
				winners[j][1]=a.get(j).split(" ")[3];
				j++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		Main main = new Main();
	}

}

package Tools;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Cell {
	public int x;
	public int y;
	public ImageIcon image;

	public Cell(int x, int y) {
		if (x < -1 | x > 1 | y < -1 | y > 1 | (x != 0 & y != 0))
			throw new IllegalArgumentException();
		this.x = x;
		this.y = y;
	}

	public void setImage(ImageIcon image) {
		this.image = image;
		this.image.setImage(image.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH));
	}
}

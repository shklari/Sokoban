package Tools;
import javax.swing.ImageIcon;

import Ticks.Tower;

public class Grass extends Cell {

	public Tower t;

	public Grass(int x, int y) {
		super(x, y);
		setImage(new ImageIcon("src/pics/Grass.jpg"));
		t = null;
	}

}

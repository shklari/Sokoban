package Tools;
import java.util.LinkedList;


import javax.swing.ImageIcon;


import Ticks.*;

public class Road extends Cell {
	public LinkedList<Creep> creep;
	

	public Road(int x, int y) {
		super(x, y);
		setImage(new ImageIcon("src/pics/Road.png"));

		creep = new LinkedList<Creep>();
	}

	public void setImage() {
		setImage(new ImageIcon("src/pics/Road.png"));
	}

}

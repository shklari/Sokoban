package bgu.spl.a2.sim;

import java.util.List;

public class GeneralAction {


    String Action;
    String Department;
    String Course;
    String Student;
    List<String> Prerequisites;
    List<String> Grade;
    String Computer;
    List<String> Students;
    List<String> Conditions;
    String Space;
    String Number;
    List<String> Preferences;

}

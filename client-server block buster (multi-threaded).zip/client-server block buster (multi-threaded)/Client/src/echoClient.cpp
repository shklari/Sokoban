#include <stdlib.h>
#include "../include/connectionHandler.h"
#include <boost/thread.hpp>
using namespace std;
#include <atomic>
/**
* This code assumes that the server replies the exact text the client sent it (as opposed to the practical session example)
*/
class  Recieve{
private:
    ConnectionHandler *handler;
    bool* end;
    bool* doneprog;
public:
    Recieve(bool *end, bool *getAns,ConnectionHandler *handler):end(end), doneprog(getAns), handler(handler)  {}

    void run() {
        // We can use one of three options to read data from the server:
        // 1. Read a fixed number of characters
        // 2. Read a line (up to the newline character using the getline() bufs fered reader
        // 3. Read up to the null character
        std::string answer;
        // Get back an answer: by using the expected number of bytes (len bytes + newline delimiter)
        // We could also use: connectionHandler.getline(answer) and then get the answer without the newline char at the end
        while(!*end) {
            answer = "";
            if (!handler->getLine(answer)) {
                std::cout << "Disconnected. Exiting...\n" << std::endl;
                break;
            }

            int len = answer.length();
            // A C string must end with a 0 char delimiter.  When we filled the answer buffer from the socket
            // we filled up to the \n char - we must make sure now that a 0 char is also present. So we truncate last character.
            answer.resize(len - 1);
            std::cout << answer << " "  << std::endl;
            if (answer == "ACK SIGNOUT succeeded") {
                std::cout << "Exiting...\n" << std::endl;
                *end = true;
                *doneprog = true;
            }
            if(answer == "ERROR SIGNOUT failed"){
                *doneprog = true;
            }
        }
        return;
    }
};

class  Send{
    private:
    bool *end;
    bool *doneprog;
    ConnectionHandler* handler;
    public:
        Send(bool *end, bool *getAns,ConnectionHandler *handler):end(end), doneprog(getAns), handler(handler) {}

        void run() {
            //From here we will see the rest of the ehco client implementation:
            cout<< "client connected" << "\n";
            const short bufsize = 1024;
            char buf[bufsize];
            while (!*end) {

                std::cin.getline(buf, bufsize);
                std::string line(buf);
                int len = line.length();
                if (!handler->sendLine(line)) {
                    std::cout << "Disconnected. Exiting...\n" << std::endl;
                    return;
                }
                if(line == "SIGNOUT"){
                    while(!*doneprog)
                    {}
                    *doneprog = false;
                    *end = true;
                }
                // connectionHandler.sendLine(line) appends '\n' to the message. Therefor we send len+1 bytes.

            }
        }
};

int main(int argc, char *argv[]) {
    bool* end = new bool(false);
    bool* doneprog = new bool(false);
    /*if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " host port" << std::endl << std::endl;
        return -1;
    }

    std::string host = argv[1];

    short port = atoi(argv[2]);

*/

    std::string host = argv[1];

    short port = atoi(argv[2]);
cout << host << " " << port;
    ConnectionHandler connectionHandler(host, port);

    if (!connectionHandler.connect()) {
        std::cerr << "Cannot connect to " << host << ":" << port << std::endl;

        return 1;
    }

    //hahdasosh
    Send send(end,doneprog,&connectionHandler);
    Recieve recieve(end,doneprog,&connectionHandler);
    //boost::thread* thr = new boost::thread(boost::bind(&Send::run,&send));
    boost::thread th1(&Send::run,&send);
    recieve.run();
    //joins the read task
    th1.join();




    return 0;

}


package bgu.spl181.net.impl.bidi;

import bgu.spl181.net.impl.BlockBuster.BlockBusterSystem;

/**
 * Created by מחשב on 08/01/2018.
 */
public abstract class BidiProtAbs implements BidiMessagingProtocol {

    int connectionId;
    String username = "";
    Connections connections;
    BlockBusterSystem block;
    boolean isLogedIn = false, shouldterm = false;

    public BidiProtAbs(BlockBusterSystem block){this.block = block;}

    @Override
    public void start(int connectionId, Connections connections) {
        this.connectionId = connectionId;
        this.connections = connections;
    }

    @Override
    public boolean shouldTerminate() {
        return shouldterm;
    }


    protected abstract String register(String[] commands);

    protected String login(String[] commands) throws IndexOutOfBoundsException {
        String username = commands[1];
        String password = commands[2];
        boolean actionSucceed = !isLogedIn && block.login(username, password);
        if (actionSucceed) {
            isLogedIn = true;
            this.username = username;
            return "ACK login succeeded";
        } else
            return "ERROR login failed";
    }

    protected String signout(String[] commands) throws IndexOutOfBoundsException {
        if (block.signout(username)) {
            shouldterm = true;
            connections.send(connectionId, "ACK SIGNOUT succeeded");
            connections.disconnect(connectionId);
            return "";
        }
        else
            return "ERROR SIGNOUT failed";
    }

    protected abstract String request(String[] commands);
}

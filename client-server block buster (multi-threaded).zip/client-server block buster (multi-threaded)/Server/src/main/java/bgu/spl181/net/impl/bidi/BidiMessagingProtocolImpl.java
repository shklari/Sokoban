package bgu.spl181.net.impl.bidi;

import bgu.spl181.net.impl.BlockBuster.BlockBusterSystem;
import bgu.spl181.net.impl.BlockBuster.Movie;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by מחשב on 04/01/2018.
 */
public class BidiMessagingProtocolImpl extends BidiProtAbs {



    public BidiMessagingProtocolImpl(BlockBusterSystem block) {
        super(block);
    }


    protected String register(String[] commands) throws IndexOutOfBoundsException {
        String username = commands[1];
        String password = commands[2];
        String country = "";
        if (commands.length > 3) {
            int contryIndex = commands[3].indexOf("=") + 1;
            country = commands[3].substring(contryIndex + 1, commands[3].length()-1);
        }
        if (!block.register(username, password, country)) {
            return "ERROR register failed";
        }
        return "ACK register succeeded";
    }

    protected String request(String[] commands) throws IndexOutOfBoundsException {
        String requestType = commands[1];
        switch (requestType) {
            case ("balance"):
                String balanceType = commands[2];
                if (balanceType.equals("info")) {
                    Integer amount = block.balanceInfo(username);
                    return "ACK balance " + amount.intValue();
                } else if (balanceType.equals("add")) {
                    int amount = Integer.parseInt(commands[3]);
                    int newAmount = block.addAmount(username, amount);
                    return "ACK balance " + newAmount + " added " + amount;
                } else
                    return null;
            case ("info"):
                List<Movie> movies;
                String movieName = "";
                //check if the user ask for a spesific movie and get the movie name
                if (commands.length >= 3) {
                    for (int i = 2; i < commands.length; i++) {
                        movieName = movieName + " " + commands[i];
                    }
                    //remove the "" from the movie name
                    movieName = movieName.substring(2, movieName.length() - 1);
                }
                movies = block.info(movieName);
                if (movies == null)
                    return null;
                else {
                    if (movies.size() == 1) {
                        return "ACK info " + movies.get(0).toString();
                    } else {
                        String output = "ACK info ";
                        for (Movie m : movies) {
                            output = output + "\"" + m.getName() + "\" ";
                        }
                        if (output.length() > 2)
                            output = output.substring(0, output.length() - 1);
                        return output;
                    }
                }
            case ("rent"):
                String moviename = parse(commands);
                Movie rentMovie = block.rent(username, moviename);
                if (rentMovie == null)
                    return null;
                else {
                    String mess = "BROADCAST movie \"" + rentMovie.getName() + "\" "
                            + rentMovie.getAvailableAmount() + " " + rentMovie.getPrice();
                    String brodecastMessage = new String(mess);
                    brodecastMessage = mess;
                    //connections.broadcast(brodecastMessage);
                    return "ACK rent \"" + rentMovie.getName() + "\"  success" + mess;
                }
            case ("return"):
                moviename = parse(commands);
                rentMovie = block.returnmovie(username, moviename);
                if (rentMovie != null) {
                    String mess = "BROADCAST movie \"" + rentMovie.getName() + "\" "
                            + rentMovie.getAvailableAmount() + " " + rentMovie.getPrice();
                    String brodecastMessage = new String(mess);
                    brodecastMessage = mess;
                    //connections.broadcast(brodecastMessage);
                    return "ACK return \"" + moviename + "\" success" + mess;
                } else
                    return null;
            case ("addmovie"):
                moviename = parse(commands);
                int i = 0;
                while (!commands[i].endsWith("\""))
                    i++;
                i++;
                int amount = Integer.parseInt(commands[i++]);
                int price = Integer.parseInt(commands[i++]);
                List<String> band = new ArrayList<>();
                String country = "";
                for (; i < commands.length; i++) {
                    if (commands[i].endsWith("\"")) {
                        country = country + commands[i];
                        country = country.substring(1, country.length() - 1);
                        band.add(country);
                        country = "";
                    } else {
                        country = country + commands[i] + " ";
                    }
                }
                Movie newMovie = block.addmovie(username, moviename, amount, price, band.toArray(new String[band.size()]));
                if (newMovie == null)
                    return null;
                else {
                    String mess = "BROADCAST movie \"" + newMovie.getName() + "\" "
                            + newMovie.getAvailableAmount() + " " + newMovie.getPrice();
                    String brodecastMessage = new String(mess);
                    brodecastMessage = mess;
                    //connections.broadcast(brodecastMessage);
                    return "ACK addmovie \"" + moviename + "\" success" + mess;
                }
            case ("remmovie"):
                moviename = parse(commands);
                boolean succeed = block.remmovie(username, moviename);
                if (succeed) {
                    String mess = "BROADCAST movie \"" + moviename + "\" removed";
                    String brodecastMessage = new String(mess);
                    brodecastMessage = mess;
                    //connections.broadcast(brodecastMessage);
                    return "ACK remmovie \"" + moviename + "\" success" + mess;
                } else
                    return null;
            case ("changeprice"):
                moviename = parse(commands);
                price = 0;
                if (commands.length >= 3) {
                    try {
                        price = Integer.parseInt(commands[commands.length - 1]);
                    }catch (Exception ex) {return null;}
                } else
                    return null;
                Movie movie = block.changeprice(username, moviename, price);
                if (movie != null) {
                    String mess = "BROADCAST movie \"" + movie.getName() + "\" "
                            + movie.getAvailableAmount() + " " + movie.getPrice();
                    String brodecastMessage = mess;
                    //connections.broadcast(brodecastMessage);
                    return "ACK changeprice \"" + moviename + "\" success" + mess;
                } else
                    return null;
        }
        return null;
    }

    public void addBlock(BlockBusterSystem b){this.block = b;}

    private String parse(String[] commands) {
        String moviename = "";
        int i = 0;
        while (i < commands.length && !commands[i].startsWith("\""))
            i++;
        if(commands[i].endsWith("\"") && commands[i].startsWith("\""))
            return commands[i].substring(1,commands[i].length()-1);
        do {
            moviename = moviename + commands[i] + " ";
            i++;
        } while (i < commands.length && !commands[i].endsWith("\""));
        if(i < commands.length && commands[i].endsWith("\""))
            moviename = moviename + commands[i];
        return moviename.substring(1, moviename.length() - 1);

    }

    @Override
    public void process(Object message) {
        String command = (String) message, name;
        String[] comnds = command.split(" ");
        String output = null;
        try {
            name = comnds[0].toUpperCase();
            switch (name) {
                case ("REGISTER"):
                    if (!isLogedIn)
                        output = register(comnds);
                    break;
                case ("LOGIN"):
                    if (!isLogedIn)
                        output = login(comnds);
                    break;
                case ("SIGNOUT"):
                    if (isLogedIn)
                        output = signout(comnds);
                    break;
                case ("REQUEST"):
                    if (isLogedIn)
                        output = request(comnds);
                    break;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            output = "ERROR " + comnds[0].toUpperCase() + " failed";
        }
        if (output == null) {
            if(comnds[0].toUpperCase().equals("REQUEST"))
                output = "ERROR " + comnds[0] + " " + comnds[1] + " failed";
            else
                output = "ERROR " + comnds[0] + " failed";
        }

        if(!shouldTerminate()) {
            String tobroad = null;
            if (output.contains("BROADCAST")) {
                int broad = output.indexOf("BROADCAST");
                tobroad = output.substring(broad);
                output = output.substring(0, broad);
            }
            connections.send(connectionId, output);
            if (tobroad != null)
                connections.broadcast(tobroad);

        }
    }

}




package bgu.spl181.net.impl.BlockBuster;

import com.google.gson.Gson;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by מחשב on 04/01/2018.
 */
public class BlockBusterSystem implements Serializable {

    Movies movies;
    Users users;
    AtomicInteger counter;
    ConcurrentHashMap<String,AtomicBoolean> logged;
    ConcurrentHashMap<String, User> usersId;

    public BlockBusterSystem(Users u, Movies m) {
        logged = new ConcurrentHashMap<>();
        usersId = new ConcurrentHashMap<>();
        users = u;
        movies = m;
        counter = new AtomicInteger(movies.movies.size());

        for (User user : users.users) {
            usersId.put(user.username, user);
            logged.put(user.username, new AtomicBoolean(false));
        }
    }

    public boolean register(String userName, String password, String optional){
        User newUser = new User(userName,password,optional);
        if(usersId.get(userName) != null)
            return false;
        usersId.put(userName, newUser);
        logged.put(userName, new AtomicBoolean(false));
        users.users.add(newUser);
        usertoJson();
        return true;
    }

    public boolean login(String username, String password){
        User user = usersId.get(username);
        if(user == null)
            return false;
        if(!password.equals(user.password))
            return false;
        AtomicBoolean bool = logged.get(username);
        return bool.compareAndSet(false, true);
    }

    public boolean signout(String username){
        AtomicBoolean bool = logged.get(username);
        return bool != null && bool.compareAndSet(true, false);
    }

    public Integer balanceInfo(String username){
        return usersId.get(username).getBalance();
    }

    public Integer addAmount(String username,int amount){
        User user = usersId.get(username);
        user.addAmount(amount);
        usertoJson();
        return user.getBalance();
    }

    public List<Movie> info(String moviename){
        List<Movie> info = new ArrayList<>();
        if(moviename.length() == 0){
            return this.movies.movies;
        }
        for(Movie movie : movies.movies){
            if(movie.name.equals(moviename)){
                info.add(movie);
                return info;
            }
        }
        return null;
    }

    public Movie rent(String username, String moviename){
        AtomicBoolean bool = logged.get(username);
        if(bool == null || !bool.get()){//checks if the user is logged in
            return null;
        }
        User user = usersId.get(username);
        Movie mov = null;
        for(Movie movie : movies.movies){//finds the movie and decrements the available copies
            if(movie.name.equals(moviename)){
                int copies = movie.decreseAmount();
                if(copies < 0){
                    movie.increaseAmount();
                    return null;
                }
                mov = movie;
            }
        }
        if(mov == null || user.getBalance() < mov.getPrice())
            return null;
        String[] list = mov.getBannedCountries();
        for(int i = 0; i < list.length; i++){//checked if user in banned country
            if(list[i].equals(user.country))
                return null;
        }
        List <LikeAMovie> usermovie = user.movies;
        LikeAMovie likeAMovie = new LikeAMovie(mov);
        if(usermovie.contains(likeAMovie))
            return null;
        user.addMovie(mov);
        user.addAmount(-1 * (mov.getPrice()));
        blocktoJson();
        return mov;
    }

    public Movie returnmovie(String username, String moviename){
        Movie mov = null;
        for(Movie movie : movies.movies){//checks if movie exists
            if(movie.name.equals(moviename)){
                mov = movie;
            }
        }
        if(mov == null)
            return null;
        AtomicBoolean bool = logged.get(username);
        if(bool == null || !bool.get()){//checks if the user is logged in
            return null;
        }
        User user = usersId.get(username);
        LikeAMovie likeAMovie = new LikeAMovie(mov);
        //check if the user rent this movie
        if(!user.movies.contains(likeAMovie)){
            return null;
        }
        mov.increaseAmount();
        user.movies.remove(likeAMovie);
        blocktoJson();
        return mov;
    }

    public Movie addmovie(String username, String moviename, Integer amount, Integer price, String[] banned){
        User user = usersId.get(username);
        if(user == null || !user.type.equals("admin"))
            return null;
        if(price.intValue() <= 0 || amount.intValue() <= 0)
            return null;
        for(Movie movie : movies.movies){
            if(movie.name.equals(moviename))
                return null;
        }
        Movie toadd = new Movie(counter.incrementAndGet(), moviename, price, banned, amount);
        movies.movies.add(toadd);
        movietoJson();
        return toadd;
    }

    public boolean remmovie(String username, String moviename){
        User user = usersId.get(username);
        if(user == null || !user.type.equals("admin"))
            return false;
        Movie mov = null;
        for(Movie movie : movies.movies){
            if(movie.name.equals(moviename))
                mov = movie;
        }
        if(mov == null || mov.getAvailableAmount() < mov.getTotalAmount())
            return false;
        if(mov.comperAndSetAmount(0)){
            boolean answer = movies.movies.remove(mov);
            movietoJson();
            return answer;
        }
        return false;
    }

    public Movie changeprice(String username, String moviename, Integer price){
        User user = usersId.get(username);
        if(price.intValue() <= 0 || user == null || !user.type.equals("admin"))
            return null;
        Movie mov = null;
        for(Movie movie : movies.movies){
            if(movie.name.equals(moviename))
                mov = movie;
        }
        if(mov == null)
            return null;
        mov.setPrice(price);
        movietoJson();
        return mov;
    }

    private synchronized void usertoJson() {
        try (FileWriter writer = new FileWriter("DATABASE/example_Users.json")) {
            Gson g = new Gson();
            writer.write(g.toJson(users));
        } catch (IOException o) {
            throw new RuntimeException(("Bad IO"));
        }
    }

    private synchronized void movietoJson(){
        try (FileWriter writer = new FileWriter("DATABASE/example_Movies.json")) {
            Gson g = new Gson();
            writer.write(g.toJson(movies));
        } catch (IOException o) {
            throw new RuntimeException(("Bad IO"));
        }
    }

    private void blocktoJson(){
        movietoJson();
        usertoJson();
    }

    public List<Movie> getMovies(){return movies.movies;}

    public static BlockBusterSystem toGson() {//Read the configuration file and turn into a java object (MainOrder Object)
        Gson gson = new Gson();
        BlockBusterSystem b = null;
        try (FileReader r1 = new FileReader
                ("DATABASE/example_Users.json");
             FileReader r2 = new FileReader
                     ("DATABASE/example_Movies.json")) {
            Movies movies = gson.fromJson(r2, Movies.class);
            Users u = gson.fromJson(r1, Users.class);
            b = new BlockBusterSystem(u, movies);
        } catch (IOException e) {
            System.out.println("Configuration file not found.");
        }
        return b;

    }

}

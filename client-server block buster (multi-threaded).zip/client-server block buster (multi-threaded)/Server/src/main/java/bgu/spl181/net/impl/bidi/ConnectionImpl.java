package bgu.spl181.net.impl.bidi;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ConnectionImpl implements Connections {

    ConcurrentHashMap<Integer,ConnectionHandler> currentConnections;
    AtomicInteger counter = new AtomicInteger(0);

    public ConnectionImpl(){
        currentConnections = new ConcurrentHashMap();
    }

    synchronized public boolean send(int connectionId, Object msg)
    {
        ConnectionHandler handler = currentConnections.get(connectionId);
        if(handler == null)
            return false;
        handler.send(msg);
        return true;
    }

    public void broadcast(Object msg) {
        for(int i = 0; i< currentConnections.size(); i++){
            send(i, msg);
        }
    }

    public void disconnect(int connectionId) {
        //ConnectionHandler handler = currentConnections.get(connectionId);

        currentConnections.remove(connectionId);
    }

    public int connect(ConnectionHandler handler){
        int i = counter.getAndIncrement();
        currentConnections.put(i, handler);
        return i;
    }

}

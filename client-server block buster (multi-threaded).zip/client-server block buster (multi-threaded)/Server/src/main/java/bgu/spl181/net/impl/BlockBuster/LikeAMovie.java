package bgu.spl181.net.impl.BlockBuster;

import java.io.Serializable;

/**
 * Created by מחשב on 06/01/2018.
 */
public class LikeAMovie implements Serializable{

    String id;
    String name;

    public LikeAMovie(Movie movie){
        id = movie.id;
        name = movie.getName();
    }

    @Override
    public boolean equals(Object other){
        if (other instanceof LikeAMovie){
            LikeAMovie likeamovie =(LikeAMovie)other;
            return (likeamovie.id.equals(id) && likeamovie.name.equals(name));
        }
        return false;
    }
}

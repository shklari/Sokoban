package bgu.spl181.net.impl.BBreactor;

import bgu.spl181.net.impl.BlockBuster.BlockBusterSystem;
import bgu.spl181.net.impl.BlockBuster.Movies;
import bgu.spl181.net.impl.BlockBuster.Users;
import bgu.spl181.net.impl.bidi.BidiMessagingProtocolImpl;
import bgu.spl181.net.impl.bidi.LineMessageEncoderDecoder;
import bgu.spl181.net.impl.bidi.Server;
import com.google.gson.Gson;

import java.io.FileReader;
import java.io.IOException;

public class ReactorMain {

    public static void main(String [] args){
        BlockBusterSystem block = BlockBusterSystem.toGson();
        if(block == null)
            return;
        Server server = Server.reactor(8,Integer.parseInt(args[0]), ()-> {return new BidiMessagingProtocolImpl(block);}, ()-> {return new LineMessageEncoderDecoder();});
        server.serve();
    }


}

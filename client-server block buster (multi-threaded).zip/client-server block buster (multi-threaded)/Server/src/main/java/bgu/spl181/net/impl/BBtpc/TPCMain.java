package bgu.spl181.net.impl.BBtpc;
import bgu.spl181.net.impl.bidi.*;
import bgu.spl181.net.impl.BlockBuster.BlockBusterSystem;
import bgu.spl181.net.impl.bidi.BidiMessagingProtocolImpl;
import bgu.spl181.net.impl.bidi.Server;


public class TPCMain {

    public static void main(String[] args) {
        BlockBusterSystem block = BlockBusterSystem.toGson();
        if (block == null)
            return;
        Server server = Server.threadPerClient(Integer.parseInt(args[0]), () -> {
            return new BidiMessagingProtocolImpl(block);
        }, () -> {
            return new LineMessageEncoderDecoder();
        });
        server.serve();
    }


}

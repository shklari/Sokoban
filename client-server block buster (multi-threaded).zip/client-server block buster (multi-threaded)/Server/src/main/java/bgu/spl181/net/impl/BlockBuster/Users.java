package bgu.spl181.net.impl.BlockBuster;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by מחשב on 06/01/2018.
 */
public class Users {

    List<User> users;


    public Users(){
        users = new ArrayList<>();
    }

}

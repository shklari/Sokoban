package bgu.spl181.net.impl.BlockBuster;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by מחשב on 06/01/2018.
 */
public class Movies implements Serializable{

    List<Movie> movies;

    public Movies(){
        movies = new ArrayList<>();
    }

}

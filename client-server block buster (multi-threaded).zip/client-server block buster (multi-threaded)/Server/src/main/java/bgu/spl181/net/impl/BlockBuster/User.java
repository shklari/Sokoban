package bgu.spl181.net.impl.BlockBuster;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by מחשב on 04/01/2018.
 */
public class User implements Serializable {

    String username;
    String type;
    String password;
    String country;
    List<LikeAMovie> movies;
    String balance;

    public User(String username,  String password, String country){
        this.username = username;
        this.type = "normal";
        this.password = password;
        this.country = country;
        movies = new ArrayList<LikeAMovie>();
        balance = "0";

    }

    @Override
    public boolean equals(Object other){
        if(!(other instanceof User))
            return false;
        return ((User) other).username == username;
    }
    public String getUsername(){return username;}

    public String getType(){return type;}

    public String getPassword(){return password;}

    public String getCountry(){return country;}

    public Integer getBalance(){return Integer.parseInt(balance);}

    public void addAmount(int amount){
        int cur = Integer.parseInt(this.balance) + amount;
        balance = cur + "";
    }

    public void addMovie(Movie movie){
        movies.add(new LikeAMovie(movie));
    }

    @Override
    public String toString(){
        return username + ", " + type  +", " ;
    }

}

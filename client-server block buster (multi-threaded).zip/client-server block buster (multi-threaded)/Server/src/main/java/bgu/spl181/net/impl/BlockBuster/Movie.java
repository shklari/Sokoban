package bgu.spl181.net.impl.BlockBuster;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by מחשב on 04/01/2018.
 */
public class Movie implements Serializable {

    String id;
    String name;
    String price;
    String [] bannedCountries;
    String availableAmount;
    String totalAmount;

    public Movie(Integer id, String name, Integer price, String[] bannedCountries, Integer total){
        this.id = id + "";
        this.name = name;
        this.price = price + "";
        this.bannedCountries = bannedCountries;
        this.availableAmount = total + "";
        this.totalAmount = total + "";
    }

    public String getName(){return name;}

    public Integer getPrice(){return Integer.parseInt(price);}

    public String[] getBannedCountries(){return bannedCountries;}

    public int getAvailableAmount(){return Integer.parseInt(availableAmount);}

    public int decreseAmount(){
        synchronized (availableAmount) {
            int newAmount = Integer.parseInt(availableAmount) - 1;
            availableAmount = newAmount + "";
            return newAmount;
        }
    }

    public int increaseAmount() {
        synchronized (availableAmount) {
            int newAmount = Integer.parseInt(availableAmount) + 1;
            availableAmount = newAmount + "";
            return newAmount;
        }
    }

    public void setPrice(int i ){
        price = i + "";
    }

    public boolean comperAndSetAmount(int i) {
        synchronized (availableAmount) {
            availableAmount = i + "";
            return true;
        }
    }

    public Integer getTotalAmount (){return Integer.parseInt(totalAmount);}

    @Override
    public String toString(){
        String output ="\"" + name + "\" " +availableAmount + " " + price;
        if(bannedCountries.length > 0) {
            output = output + " ";
            for (int i = 0; i < bannedCountries.length; i++) {
                output = output + "\"" + bannedCountries[i] + "\" ";
            }
            return output.substring(0, output.length() - 1);
        }
        return output;
    }

}
